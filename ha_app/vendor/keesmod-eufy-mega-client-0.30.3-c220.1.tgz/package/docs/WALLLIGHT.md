# Wall-light camera software evidence

Story [#31](https://github.com/keesmod/eufy-mega-client/issues/31) adds exact
recognition, observed state and event routing to 0.12.0. Tests use
synthetic inventories and the actual private protocol classes. They do not
establish physical support.

## Recognition, state and events

| Model | Type  | Product                   | Battery                          | Availability                |
| ----- | ----- | ------------------------- | -------------------------------- | --------------------------- |
| T84A1 | 151   | Wired Wall Light Cam S100 | Unknown, no mapped property      | Unknown, no mapped property |
| T81A0 | 10005 | Solar Wall Light Cam S120 | Validated observation or unknown | Unknown, no mapped property |

The exact pairs come from the [model matrix](MODEL_MATRIX.md). Their firmware is
reported only when supplied. The attributed `DeviceProperties` at client commit
`34863d81eb3bc50dbc095ff537fe156640f7042e` has no `DeviceState` mapping for either
model. A generic status parameter or a connected HomeBase therefore cannot turn
availability into online. T84A1 also has no battery mapping. T81A0 accepts observed
zero and rejects malformed or out-of-range battery values.

The existing `WallLightCam` class is reused because it decodes native motion and
person push messages and updates detection state. These are concrete differences
from generic `Camera`. No new family adapter or vendor protocol is introduced.
The MIT camera source retains its [attribution](../NOTICE.md).

Each camera keeps its actual inventory parent, channel and public identifier.
A T8030/type 18 parent selects the existing station route. An empty or self
parent retains a camera descriptor with `standalone_transport_unverified`,
without creating a HomeBase entity, opening a connection or enabling events.
The experimental standalone S100 below is the only wall-light opt-in exception.
Other owners return `unsupported_station`. Unknown or mismatched model/type pairs
return `unsupported_device`. Adapter initialization failures remain local to the
camera. Changing an owner removes old listeners and observations.

Only motion/person properties enable their respective detections. Ring codes
cannot produce a ring on these cameras. Native pushes, H3 companion messages,
local detections and replay use existing owner checks and duplicate suppression.
Unknown names stay unknown. Light settings, PTZ, talkback and other controls are
outside these stories.

[Wall-light tests](../test/walllight.test.mjs) cover both exact adapters, public
inventory/state, unsupported variants, bad initialization, wrong owners/channels,
unknown state, observed battery, parent changes, native push state conversion,
event correlation and standalone descriptors alongside other camera families.

## Media and remaining work

Story [#32](https://github.com/keesmod/eufy-mega-client/issues/32) admits only
**T81A0/type 10005 with an actual matching T8030/type 18 inventory parent**.
The owner must have the T8030 serial prefix and the existing additional-H3
four-part numeric firmware admission at or above 2.0.9.7. Credentials remain
LAN-derived. This is a conditional experimental software route, not a claim that
all S120 installations use HomeBase as their command owner. An empty/self parent
never becomes an H3 parent because the product supports HomeBase storage.

The official [compatibility guide][HB-guide] lists S120 with H3. The official
[battery Wall-light connection FAQ][Wall-FAQ] describes connection and a stream
test, requiring the same network, home and account. Neither source provides a
wire protocol or confirms this library on hardware. The FAQ labels a firmware
value as HomeBase 3-2.1.1.9. We have no independent confirmation of that value's
meaning. We do not derive a new firmware requirement from it. The existing
2.0.9.7 software admission boundary remains a library policy, not a measured S120
firmware minimum. Test firmware 1.2.3 for the camera and 3.8.6.0 for its owner are
synthetic branch inputs.

T84A1/type 151 remains `camera_media_unverified` for snapshots, live and recording
media even with an H3 inventory parent. Its matrix evidence establishes H3
storage, with unresolved AI/owner behavior. Storage compatibility alone cannot
establish which device owns commands. T84A1 keeps recognition/state/events from
#31. Its remaining transport/owner obligation is tracked in #142. #61 held its
hardware obligation until it was closed as not planned on 2026-09-16.

### Reused media commands

The attributed source at commit `34863d81eb3bc50dbc095ff537fe156640f7042e` supplies
`Station.startLivestream`, `stopLivestream`, `startDownload`, `cancelDownload`,
`databaseQueryLatestInfo`, `downloadImage`, `databaseQueryByDate` and
`databaseCountByDate`. `Device.isWallLightCam` explicitly includes type 10005,
and its command table declares the existing media operations. Each Station
operation checks the device's actual station serial and command support.
No new vendor code, credential lookup or legacy security-cloud fallback is added.

- Live uses the existing `CMD_DOORBELL_SET_PAYLOAD`, `commandType=1000`,
  `accountId`, public `encryptkey` and `streamtype` 0/1 for H.264/H.265. It does
  not add the pan/tilt branch's `camera_type` or `entrytype` fields.
- Live stop uses `CMD_STOP_REALTIME_MEDIA` on the actual channel. Both a matching
  acknowledgement and local stop are required. Missing or rejected ACK remains
  unconfirmed, with bounded cleanup and connection disposal.
- Stored snapshots query the latest HomeBase cover and use `CMD_DATABASE_IMAGE`.
  These are stored images, not a fresh camera exposure.
- Recording metadata uses `CMD_DATABASE_COUNT_BY_DATE` and
  `CMD_DATABASE_QUERY_BY_DATE`. H3 downloads reuse `CMD_SET_PAYLOAD` with
  `CMD_DOWNLOAD_VIDEO`, file path and public download key. Cancellation uses
  `CMD_DOWNLOAD_CANCEL` and requires acknowledgement. The old upstream H3 TODO
  is preserved. It is neither a new failure observation nor a hardware guarantee.

The [T81A0 fixture](../test/fixtures/walllight-media.mjs) joins the existing
[media](../test/eufycam-media.test.mjs), [capability](../test/capabilities.test.mjs)
and [lifecycle](../test/family-lifecycle.test.mjs) tests. Checks assert full vendor
command envelopes for both codecs, snapshot bytes, separate video/audio bytes,
metadata, thumbnails, completed/cancelled downloads, wrong/missing/rejected ACK,
late events and repeated cleanup. Failure of one owner's live stream must leave
a second owner's audio working. Invalid tuples, owners and firmware reject media
before start. A separate S100 regression checks all blocked media operations.
Synthetic bytes do not prove physically decodable or audible video/audio.

These new T81A0 tests first failed on #31's media-unverified baseline and pass
with its exact additional-H3 admission. The existing shared lifecycle and public
API remain unchanged. Further actual topology evidence can refine admission
without restricting ordinary library upgrades.

## Experimental standalone S100, 0.29.0

With the client option `experimentalStandalone`, a T84A1/type 151 with an empty
or self parent becomes its own local owner, as described in
[API.md](API.md#experimental-standalone-cameras). The camera is then the
station of the reused Station operations above. Its type 151 command table
declares `downloadImage`, `databaseQueryLatestInfo`, `databaseQueryByDate` and
`databaseCountByDate`, and live uses the Wall-light branch above. The session
uses the existing local lookup and LAN-derived command key. On 2026-10-17 a
standalone S100 on firmware 1.1.0.4 was reported with a working snapshot and
live video with audio. Live START is sent only after the session has set that
key, so this firmware accepted it. This is a reported result, not independently
reproduced, as recorded in the
[model matrix](MODEL_MATRIX.md#reported-standalone-t84a1-result-2026-10-17).
Whether it answers the database commands with its own storage is unknown. Since 0.30.1 its recordings report
`standalone_recordings_unverified`, as on every experimental standalone camera,
because no request has enough evidence to list and play recordings on that
route. Its thumbnail
and download are refused before any connection, a download with a cipher ID
first with `recording_cipher_unavailable`. Guard mode stays off. Since 0.30.1
its motion and person pushes become detection events, see
[API.md](API.md#standalone-events-and-push-observation-0301). The [standalone tests](../test/standalone-experimental.test.mjs)
cover discovery, credentials, owner wiring, reloads, connection stages, a live
start and confirmed stop on the one session, snapshot assignment, the
unavailable recordings, the admitted motion and person pushes, and the refused
guard mode, other pushes and cipher downloads, with synthetic rows and a stubbed station. A real vendor Station is created for the type 151 row without opening
a socket. A T84A1 under a HomeBase keeps the blocked media above. Physical
results belong to [#142](https://github.com/keesmod/eufy-mega-client/issues/142).

For [ha-eufy-cam#185](https://github.com/keesmod/ha-eufy-cam/issues/185) a
standalone S100 push is admitted only as a numeric 3101 or 3102 with type 151
that names the camera as both device and station. The vendored push parser
decodes it in its type 151 IndoorPushEvent branch, and the client's detection
intake turns it into an event. The `WallLightCam` class takes no part, so its
detection state does not change. A push over the camera's open
session carries its `msg_type` as type and is admitted only if that is 151,
which no capture has shown. The
vendored station and camera push handlers, `loadEventImage` and the latest-info
query 10013 are never called on this route, so an event loads no image and
opens no connection. Every refused push is counted in `standalonePushStatus`.
The physical event result belongs to ha-eufy-cam#185.

[HB-guide]: https://service.eufy.com/article-description/eufy-Security-Complete-HomeBase-Compatibility-Guide
[Wall-FAQ]: https://service.eufy.com/article-description/FAQ-About-Wall-Light-Cam-Battery-Connection-to-Homebase3

[#142](https://github.com/keesmod/eufy-mega-client/issues/142) tracks standalone
transport and [#143](https://github.com/keesmod/eufy-mega-client/issues/143) other
HomeBase owners. [#61](https://github.com/keesmod/eufy-mega-client/issues/61)
held hardware validation for exact model, firmware, topology and feature until it
was closed as not planned on 2026-09-16. These software changes do not close
those obligations.

The [community process](COMMUNITY_VALIDATION.md) accepts voluntary results.
Missing hardware evidence alone does not block ordinary upgrades. No live test,
consumer deployment or release publication is performed here. There is no
session-store migration. Keep the preceding package and lockfile for rollback.
