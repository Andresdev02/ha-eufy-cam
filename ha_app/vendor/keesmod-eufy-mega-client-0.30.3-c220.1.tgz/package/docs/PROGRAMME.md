# Eufy platform programme

The goal is one modular Eufy client for all known camera families and the E15
mower, including settings and portable maps without Android. Each purpose has
its own bridge and Home Assistant integration. Both bridges consume the library.

The [programme issue](https://github.com/keesmod/eufy-mega-client/issues/7) and
its epics were closed on 2026-09-16 and remain readable as history. Work status
now lives in individual GitHub issues and the
[Eufy platform Project](https://github.com/users/keesmod/projects/1). Hardware
evidence status lives in the [model matrix](MODEL_MATRIX.md). This document
records decisions and working rules, not a second backlog.

## Accepted product decisions

- Keep the `eufy-mega-client` repository and `@keesmod/eufy-mega-client` package.
  Preserve the existing `EufyMegaClient` API. Add `EufyClient` with independent
  `security` and `mowers` modules.
- Share public error, lifecycle and diagnostics conventions. Keep Mega security
  authentication and Eufy Home/Tuya authentication and sessions separate.
  Camera-only, mower-only and combined library clients must work independently.
  A combined library API does not require a combined bridge service.
- Camera scope is discovery, available status and battery, stored snapshots,
  live video/audio, supported events and recordings. PTZ, talkback and the full
  set of app settings are outside this first expansion. On 2026-10-31 the owner
  selected preset moves for the exact `T8170` behind a HomeBase 3 through
  [ha-eufy-cam#229](https://github.com/keesmod/ha-eufy-cam/issues/229). Other
  PTZ remains outside.
- Cover the full known camera catalogue, including eufyCam, SoloCam, indoor,
  battery and wired doorbells, floodlight, wall-light, garage, integrated camera
  products, 4G and PoE/NVR topologies. Camera-bearing locks or parcel boxes do not
  authorize lock, door or parcel actuation.
- Classify by protocol type, model and actual topology. A marketing name such as
  S220 does not uniquely identify a device. A standalone transport owner is not
  a fabricated HomeBase alarm entity.
- Record capabilities per model, topology, firmware and feature. Recognition,
  experimental software coverage, hardware validation and an explicit blocker
  are different states. Experimental capabilities may be available, clearly
  marked. Tests with fixtures do not establish physical support.
- Unknown security credentials, stronger encryption or a missing Mega route
  remain explicit blockers. Do not silently use legacy security-cloud fallback.
- E15 includes observation, opt-in start/pause/return, independently validated
  local and cloud settings, and read-only maps. E18 remains unclaimed without
  hardware validation. Zone mowing, map editing, remote driving and automatic
  planner activation are outside the first delivery.
- Mower control requires explicit opt-in and fresh telemetry. A sent command,
  cloud response or inactive task is not proof of physical completion. Never
  automatically replay an uncertain physical command or setting write, including
  retries hidden in a transport dependency.
- Replace the Android map acquisition runtime with a portable Linux transport.
  Retain the current public map-source contract and recovery path until native
  acquisition is accepted. Completing a research story does not complete this
  feature.
- Preserve HA entity identities, dashboards, observed session history, planning
  behavior, separate session stores and explicit rollback. One selected backend
  owns a device during a transition.

## Separate bridges and integrations

The user confirmed this boundary on 2026-09-10. Each purpose owns its complete
bridge and Home Assistant integration. The shared component is the
`@keesmod/eufy-mega-client` library.

| Repository         | Responsibility                                                                                   |
| ------------------ | ------------------------------------------------------------------------------------------------ |
| `eufy-mega-client` | Reusable client API, security and mower protocol adapters, capability evidence and library tests |
| `ha-eufy-cam`      | Camera bridge, camera API, camera integration and camera installation/release artifacts          |
| `eufy-robomow-ha`  | Dedicated mower bridge, mower API, mower integration and mower installation/release artifacts    |

Each bridge instantiates the library independently. Camera and mower installations
have separate endpoints, credentials, sessions, persistent data, lifecycle and
upgrade/rollback paths. Either installation must work when the other is absent
or stopped. The library does not host an HTTP service or Home Assistant entities.
Mower routes and runtime dependencies belong in the mower repository.

[E5](https://github.com/keesmod/eufy-mega-client/issues/12) covered the separate
consumer paths until it closed on 2026-09-16. It planned the dedicated mower
bridge and its API in E5-01 through E5-03, independent packaging of that bridge
in E5-08, camera work in E5-04 and the mower integration's connection to its
own bridge in E5-05 through E5-07.

## Ownership and goal coverage

| Goal                                                           | Owner                         | Tracking                                                    |
| -------------------------------------------------------------- | ----------------------------- | ----------------------------------------------------------- |
| Shared public API, independent modules and capability evidence | Client                        | [E1](https://github.com/keesmod/eufy-mega-client/issues/8)  |
| Camera family and topology coverage                            | Client                        | [E2](https://github.com/keesmod/eufy-mega-client/issues/9)  |
| E15 discovery, telemetry, control and settings                 | Client                        | [E3](https://github.com/keesmod/eufy-mega-client/issues/10) |
| Portable Linux map acquisition, decoding and lifecycle         | Client                        | [E4](https://github.com/keesmod/eufy-mega-client/issues/11) |
| Separate bridges and Home Assistant integrations               | Camera and mower repositories | [E5](https://github.com/keesmod/eufy-mega-client/issues/12) |
| Hardware claims, migration and release preparation             | Owning repository             | [E6](https://github.com/keesmod/eufy-mega-client/issues/13) |

Implementation stories live in the repository that owns the change. The epics
in this table closed with the programme issue. The existing
[S220 report](https://github.com/keesmod/ha-eufy-cam/issues/10) remains the
original reporter's issue and was linked into E2 without a duplicate.

The [model/topology/feature evidence matrix](MODEL_MATRIX.md) records the pinned
catalogue, primary model sources and outstanding obligations from
[E1-02](https://github.com/keesmod/eufy-mega-client/issues/15). Every row must link
implementation, evidence and any blocker. Newly discovered protocol work gets
bounded follow-up stories rather than silently dropping the affected model.

## Story contract

The [community evidence and upgrade policy](COMMUNITY_VALIDATION.md), accepted
in [#117](https://github.com/keesmod/eufy-mega-client/issues/117), separates
ordinary upgrades, implemented features and hardware evidence. Reviewed community
results can establish reported or confirmed behavior without maintainer ownership
of every model. Missing hardware evidence alone does not block a qualified release.
Preserve actual protocol, migration, safety and CI gates. Use release dependencies
for the affected feature slice, not the complete programme catalogue.

Every story must state its outcome, parent epic, owning repository, exact scope,
exclusions, prerequisite issues, one- or two-day active-effort estimate,
acceptance criteria, required evidence and references. Estimates are engineering
effort, not a promise about elapsed time or autonomous-agent speed. Hardware and
access waits are tracked separately.

Ready means material design choices and prerequisites are resolved. A camera
media story must name the exact evidenced transport profile before Ready. Split
work exceeding two days by transport, behavior or validation result. Keep the
remaining obligation linked to the parent.

Research is timeboxed to at most two days. It delivers reproducible observations,
source and version references, conclusions and linked follow-up work. A proven
blocker can complete a research question while the intended feature stays open.
Do not close a parent goal just because its research children are closed.

Use these Project statuses:

| Status      | Meaning                                                              |
| ----------- | -------------------------------------------------------------------- |
| Backlog     | Scoped obligation with unresolved prerequisites or not yet selected  |
| Ready       | Dependencies resolved and safely executable within the stated effort |
| In progress | One explicitly selected item is being worked                         |
| Review      | The change and applicable software evidence are ready for review     |
| Validation  | Required integration, hardware or observation evidence is pending    |
| Done        | All acceptance criteria and evidence requirements are satisfied      |
| Blocked     | A specific external or protocol blocker prevents meaningful progress |

At the start of each session, read the live issue, dependencies, programme
decisions and nearest repository instructions. Check the exact current head.
At the end, update the issue and Project with completed work, remaining work,
blockers, next action and PR/evidence links. Do not start another product story
implicitly. No daily background monitoring is requested.

PRs reference their story. Avoid automatic closing keywords while that story's
hardware validation remains pending. A software story can finish when its own
criteria pass and separate hardware obligations stay linked. A merge moves work
to Validation when its own acceptance needs more evidence. Preserve required CI and do not introduce
workflow bypasses or a second status source in local files.

The [11 September dependency review](COMMUNITY_BACKLOG_REVIEW_2026_09_11.md)
records the application of this policy to existing obligations. Live issues remain
authoritative.

## Evidence, provenance and rollout

The MIT camera protocol adaptation remains private behind library-owned public
types. Preserve its attribution and existing lifecycle/security fixes.

The existing mower fork has no declared upstream software license. It remains
the HA consumer and a functional reference. Do not copy or mechanically
translate unlicensed source, constants, schemas, fixtures or tests into this MIT
client. Use permitted sources and independently reproduced observations with
clear provenance. Do not relicense the fork or publish it through HACS as part
of this programme setup.

Keep raw captures, credentials, local keys, complete device identifiers, footage
and private lawn geometry out of GitHub, packages and diagnostics. Public evidence
uses synthetic data, redacted outcomes and source references.

Validate the exact model, firmware, topology and requested behavior. Report
unverified effects and observation gaps. Temporary live work has backups,
bounded timing, cleanup and a checked recovery path. Safety interlocks remain
enabled. Local documentation and tracking work does not require HA reloads or
physical tests.

The setup phase changes tracking, documentation and the development workspace
only. Product work proceeds per story. Release-preparation stories do not grant
publication, deployment, purchases or destructive cleanup. Apply existing
task-specific approvals, required checks and acceptance gates to those actions.

## Starting evidence

- [E15 map signaling research](research/E15_MAP_SIGNALING.md) records the
  historical helper evidence, primary Tuya contracts and proposed #48
  experiment. The [authorized observation](research/E15_MAP_OBSERVATION_2026-09-10.md)
  adds owner-confirmed firmware, runtime credential binding and the native
  authorization buffer. The [standalone Linux receipt](research/E15_LINUX_PEER_RESPONSE_2026-09-10.md)
  now proves a correlated authenticated E15 read-only version response. Portable
  [map/file transfer](research/E15_PORTABLE_MAP_TRANSFER_2026-09-10.md) now passes
  #49 with exact private comparison and confirmed cancellation. When #49 closed on
  2026-09-10, library lifecycle, decoding, deltas and consumer acceptance were
  open under E4.
- [Client compatibility](COMPATIBILITY.md), [public API](API.md),
  [diagnostics](DIAGNOSTICS.md) and [attribution](../NOTICE.md).
- [Existing mower functionality](https://github.com/keesmod/eufy-robomow-ha/blob/main/README.md),
  [provenance policy](https://github.com/keesmod/eufy-robomow-ha/blob/main/docs/protocol-provenance.md)
  and [unresolved zone evidence](https://github.com/keesmod/eufy-robomow-ha/blob/main/docs/zone-control-research.md).
- [Tuya P2P map transfer documentation](https://developer.tuya.com/en/docs/app-development/android-sweeper-p2p?id=Kceuhdm0gboep)
  establishes the SDK behavior, not a complete portable E15 wire specification.
- Local deployment evidence and source conversations are indexed in the private
  Codex workspace context. They remain historical evidence until revalidated.

- [Portable map acquisition](MAP_ACQUISITION.md) records the #50 library adapter,
  bounded demand and last-complete behavior. Its software evidence is separate
  from the #49 hardware research and the #51 through #54 obligations. #51 closed
  as completed on 2026-09-29 and #52 through #54 as not planned on 2026-09-16.
- [Mower transport provenance](MOWER_TRANSPORT_PROVENANCE.md) records the #145
  read-only local Tuya 3.5 session, its public protocol sources and the offline
  reproduction, with a link to the subsequent bounded E15 hardware observations.
- [Typed mower telemetry](MOWER_TELEMETRY.md) records the #147 decoder, the
  definition levels and the device schema provenance. The
  [2026-09-16 observations](research/E15_TELEMETRY_OBSERVATION_2026-09-16.md)
  confirm E15 battery, Wifi and signal percentage. The
  [2026-09-19 reproduction](research/E15_ROBOT_STATUS_REPRODUCTION_2026-09-19.md)
  confirms DP 107 activity `mowing`, `paused` and `returning`. Mowing progress
  still needs an evidenced fresh read-only source.
- [Concurrent live streams on one HomeBase 3](research/CONCURRENT_LIVE_2026-09-18.md)
  records the #157 bench result: a second P2P session per camera delivered a
  second concurrent live stream on a T8030 with STOP confirmed per session.
  Since 0.13.0 the opt-in `maxLiveStreamsPerStation` (default 1) allows more
  than one live camera per station.
- [Live streams beyond 120 seconds and a free primary session](research/LIVE_BOUND_2026-09-19.md)
  records the #163 bench result: a T8030 kept one T8160 live stream running for
  ten minutes at a flat rate with STOP confirmed, and a guard mode command on an
  idle primary session succeeded while the stream ran on an extra session.
  Since 0.14.0 a raised `liveUpperBoundMs` with a per-start `maxDurationMs` can
  extend a stream beyond the 120-second default.
