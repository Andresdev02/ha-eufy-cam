# eufyCam evidence

The 0.12.0 remaining-catalogue work in
[#39](https://github.com/keesmod/eufy-mega-client/issues/39) separately adds exact
[C35/T8110/type 10035 H3 software coverage](INTEGRATED_CAMERAS.md#remaining-catalogue-addition-eufycam-c35).
The existing generic Camera class and native Solo live envelope are reused.
Observed state, H3 motion/person events and core media have software tests.
Other owners are tracked in #143 and standalone operation in #142. Variants and
hardware validation stay recorded in the [model matrix](MODEL_MATRIX.md). The
original twelve-model evidence below is preserved.

Story [#19](https://github.com/keesmod/eufy-mega-client/issues/19) adds software
coverage in 0.6.0, which was not published. The work first shipped in 0.10.0,
published on 2026-09-11. The independently authored
[regressions](../test/eufycam.test.mjs) exercise the actual private `Camera` factory,
state adapter and event route. They do not establish physical support.

## Reported T8113-Z, 0.26.0

The report on [ha-eufy-cam#129](https://github.com/keesmod/ha-eufy-cam/issues/129)
shows eufyCam 2C cameras received as `T8113-Z` with type 8 under a HomeBase 3.
0.26.0 admits exactly that model code with the T8113 row below: the same generic
Camera class, H3 topology and media policy. The reporter saw snapshots, live view
and HomeBase recordings working with that entry added locally. This is reported,
not independently reproduced. Unlisted suffixes remain `unsupported_device`. See
[MODEL_MATRIX.md](MODEL_MATRIX.md#reported-t8113-z-and-t8424-0260).

## Reported T8113-V, 0.28.2

The [2026-10-09 update on ha-eufy-cam#66][V-report] reports a `T8113-V` with
`device_type=8`, firmware 3.0.7.8, under a T8030 on firmware 3.8.7.4. Bridge
0.8.32/client 0.28.0 rejected this exact model as `unsupported_device`, so Home
Assistant never created the camera. 0.28.2 admits this exact pair using the same
Camera adapter and H3 media policy as T8113 and T8113-Z. No prefix matching or
standalone route is added. Other types, owners and unevidenced suffixes retain
their existing rejection.

The synthetic tests include the V variant in discovery, state/events and the
shared media/lifecycle fixtures. They cover stored snapshots, both live codecs,
video/audio, confirmed stop, recording metadata/download and cancellation.

On 2026-10-10 the reporter of that update [ran integration 0.8.42][V-result]
and bridge 0.8.33 with client 0.28.2 on that camera, firmware 3.0.7.8, under
the T8030 on firmware 3.8.7.4. They reported discovery as its own camera in
Home Assistant, a snapshot, live view, recording playback and motion events
working. Audio, confirmed stop, cancellation and other event types were not
reported separately. This is a reported result, not independently reproduced.
See [MODEL_MATRIX.md](MODEL_MATRIX.md#reported-issue-66-update-0282).

[V-report]: https://github.com/keesmod/ha-eufy-cam/issues/66#issuecomment-6083775017
[V-result]: https://github.com/keesmod/ha-eufy-cam/issues/66#issuecomment-6098838866

## Reported T8160-C, 0.29.2

The [2026-10-09 report on ha-eufy-cam#149][C-report] shows a `T8160-C` with
`device_type=19`, firmware 1.5.8.6 and hardware 0.0.3.7, under a T8030 on
firmware 3.8.7.4. The Eufy app shows it as a regular eufyCam 3. Bridge
0.8.33/client 0.28.2 rejected this exact model as `unsupported_device`, so Home
Assistant never created the camera. 0.29.2 admits this exact pair with the
T8160 type, the same generic Camera adapter and H3 topology. No prefix matching
or standalone route is added. Other types, owners and unevidenced forms such as
`T8160C`, `T8160-X` or lower case retain their existing rejection.

Unlike `T8113-Z` and `T8113-V`, this row is not a copy of its base row. T8160
keeps the `established` model-only media check of the original four routes,
which [is not a template](DEVICE_PROFILES.md#reading-the-policy) for new
devices. T8160-C uses the additional-H3 media policy: snapshot, live and
recordings require its actual T8030/type 18 parent with a T8030 serial prefix
and four-part owner firmware at or above 2.0.9.7. The existing owner and
firmware checks apply. The reporter's owner firmware 3.8.7.4 passes the
firmware check. The T8030 serial-prefix check cannot be confirmed from the
redacted report.

The reported firmware 1.5.8.6 and hardware 0.0.3.7 differ from the T8160
firmware 3.4.3.0 and hardware 0.2.2.6 in the same installation. The T8160
hardware evidence below therefore does not transfer to T8160-C. Whether this
revision uses the same type 19 live, download and property behavior is not
verified. The synthetic tests include T8160-C in discovery, state/events and
the shared media/lifecycle fixtures. They cover stored snapshots, both live
codecs, video/audio, confirmed stop, recording metadata/download, cancellation
and the owner and firmware rejections. Discovery and the media/lifecycle
fixtures use the reported camera and owner firmware. The state/events tests use
synthetic firmware.

On 2026-10-16 the reporter [reported][C-result] that after updating to
integration 0.8.45 and bridge 0.8.36 with client 0.29.2 all devices, the T8160-C
included, appeared right away and work with snapshots, live view, recordings and
events. The comment names no device, firmware or event type separately. Audio,
confirmed stop and cancellation were not reported. Working snapshot, live view
and recordings imply that the owner checks above passed, including the T8030
serial prefix. This is a reported result, not independently reproduced, and the
T8160 hardware evidence below still does not transfer to T8160-C. See
[MODEL_MATRIX.md](MODEL_MATRIX.md#reported-issue-149-0292).

[C-report]: https://github.com/keesmod/ha-eufy-cam/issues/149
[C-result]: https://github.com/keesmod/ha-eufy-cam/issues/149#issuecomment-6214980737

## Reported T8142-Z, 0.30.3

The [2026-10-31 report on ha-eufy-cam#236][Z-report] shows three eufyCam 2C Pro
cameras received as `T8142-Z` with `device_type=15`. The report form gives
camera firmware 3.3.8 under a T8030 on firmware 3.8.7.4. Bridge 0.8.40/client
0.30.2 rejected this exact model as `unsupported_device`, so Home Assistant
never created the cameras. 0.30.3 admits this exact pair with the T8142 type,
the same generic Camera adapter and H3 topology. No prefix matching or
standalone route is added. Other types, owners and unevidenced forms such as
`T8142Z`, `T8142-V` or lower case retain their existing rejection. `T8142R`
stays unresolved.

As with T8160-C, this row is not a copy of its base row. T8142 keeps the
`established` model-only media check of the original four routes, which
[is not a template](DEVICE_PROFILES.md#reading-the-policy) for new devices.
T8142-Z uses the additional-H3 media policy: snapshot, live and recordings
require its actual T8030/type 18 parent with a T8030 serial prefix and
four-part owner firmware at or above 2.0.9.7. The reporter's owner firmware
3.8.7.4 passes the firmware check. The T8030 serial-prefix check cannot be
confirmed from the redacted report.

The synthetic tests include T8142-Z in discovery, state/events, the type 15
livestream command and the shared media/lifecycle fixtures. They cover stored
snapshots, both live codecs, video/audio, confirmed stop, recording
metadata/download, cancellation and the owner and firmware rejections.
Discovery and the media/lifecycle fixtures use the reported camera and owner
firmware. The state/events tests use synthetic firmware. No result with this
admission is reported yet. See
[MODEL_MATRIX.md](MODEL_MATRIX.md#reported-t8142-z-0303).

[Z-report]: https://github.com/keesmod/ha-eufy-cam/issues/236

## Exact hardware validation

[Story #55 hardware evidence](hardware/T8160_2026_09_11.md) records one T8160
firmware 3.4.3.0 behind its actual T8030 firmware 3.8.6.0, using client 0.10.0
and bridge/integration 0.7.1. Discovery, reported state and battery, stored
snapshot, decoded live video/audio and stop, recording playback/seek, real HA
person event, in-flight UI cancellation with confirmed device stop, and restart
recovery were individually measured. Existing HA identities and configuration
were preserved. Other models, firmware and owners retain their separate
[hardware obligations](hardware/T8160_2026_09_11.md#remaining-hardware-tuples).

## Exact software scope

| Model | Protocol type | Power   | Discovery | Battery        | Availability  | Motion/person  |
| ----- | ------------- | ------- | --------- | -------------- | ------------- | -------------- |
| T8111 | 1             | Battery | Software  | Observed only  | Unknown       | Software on H3 |
| T8112 | 4             | Battery | Software  | Observed only  | Unknown       | Software on H3 |
| T8113 | 8             | Battery | Software  | Observed only  | Observed only | Software on H3 |
| T8114 | 9             | Battery | Software  | Observed only  | Observed only | Software on H3 |
| T8140 | 14            | Battery | Software  | Observed only  | Observed only | Software on H3 |
| T8142 | 15            | Battery | Software  | Observed only  | Observed only | Software on H3 |
| T8160 | 19            | Battery | Software  | Observed only  | Observed only | Software on H3 |
| T8161 | 23            | Battery | Software  | Observed only  | Observed only | Software on H3 |
| T8600 | 24            | Wired   | Software  | Not applicable | Observed only | Software on H3 |
| T8162 | 26            | Battery | Software  | Observed only  | Observed only | Software on H3 |
| T8144 | 49            | Battery | Software  | Observed only  | Observed only | Software on H3 |
| T8172 | 89            | Battery | Software  | Observed only  | Observed only | Software on H3 |

Model/type associations come from the pinned, attributed catalogue and primary
product sources in [MODEL_MATRIX.md](MODEL_MATRIX.md). Fixtures use synthetic
firmware 1.2.3, not firmware acceptance evidence. H3 means an admitted T8030/type
18 inventory owner with valid local connection credentials. No additional
HomeBase or connection profile is enabled. Camera serial, parent serial and
channel remain the actual inventory values. The existing SDK adds HomeBase event
properties for its T8030 serial profile. Unsupported properties remain unavailable.

T8142R and other unresolved suffixes are not aliases. Unknown model/type pairs
report `unsupported_device`. Unsupported parents retain `unsupported_station`.
The same inventory can retain usable cameras from another family. A malformed
camera initialization reports `device_initialization_failed` without a protocol
payload. Issue #143 tracks older-owner protocols and issue #142 standalone
transport.

## State contract

`listDevices()` and `discoverDevices()` include validated cloud battery and status
observations. `getDeviceState(id)` initializes the private adapter as needed and
returns the latest available device observations without opening a P2P connection.
The existing device update event carries the same fields.

`firmware` remains the reported nonempty `main_sw_version` or null. Battery is an
observed integer from 0 through 100, only where the model's property table has a
battery property. Missing values, malformed strings, booleans and out-of-range
values are null. E330 has no battery property. A supplied battery field cannot
make it a battery camera.

`availability` is an additive optional property in the public `Device` type,
returned as `online`, `offline`, `disabled` or null. It uses the existing
`CMD_GET_DEV_STATUS` property only where the model table defines it. Status 1 is
online, 2 is manually disabled, and 0/3/4/5 are offline. Missing or unknown values
are null. T8111/T8112 have no mapped status property and remain null. A HomeBase
connection, sleeping radio, push connection or successful command cannot establish
camera availability. The value is the last report, not a fresh reachability probe.

P2P runtime battery updates require the actual owner and channel and a valid
percentage. Raw device state updates require the actual owner. A changed device
relationship destroys the old camera and its observations. Existing SDK source
priority remains in place, so a lower-priority cloud refresh does not overwrite
a P2P observation. This story adds no freshness guarantee or periodic polling.

## Event contract and unsupported features

Only true SDK detections and model-supported properties enter the event route.
An eufyCam has no ring property. It cannot emit a ring, even if a push carries 3103. Existing battery-doorbell ring handling remains available. Motion/person
handling, person identity enrichment, idle-reset suppression and cross-transport
settling/replay suppression keep the existing `Detections` semantics. Unknown
notification codes retain the existing generic notification/SDK decode route.

Push routing requires the actual camera's admitted HomeBase. Wrong-owner pushes,
unsupported cameras and initialization failures cannot enter detection delivery.
HomeBase-only push messages still reach its state processor. They do not become
camera detections. The software tests include two distinct doorbell rings, one
person seen through two transports, replay suppression and invalid owner input.

The 0.6.0 discovery slice rejected newly admitted model media. The 0.7.0
profile below supersedes that guard only for its exact tuples and owner branch.
Factory classification remains separate from media evidence. Existing T8160,
T8142, T8134 and T8213 routes are preserved. No settings or non-camera controls
are added.

## Remaining obligations

- [#20](https://github.com/keesmod/eufy-mega-client/issues/20) delivers the software
  media profile below. Additional owner/encryption profiles remain outside it.
- [#55](https://github.com/keesmod/eufy-mega-client/issues/55), E2 and E6 held
  model/firmware/topology-specific hardware acceptance, including discovery,
  observed state, real events, media and recovery, until #55 closed on
  2026-09-11 and E2 and E6 on 2026-09-16. The [model matrix](MODEL_MATRIX.md)
  records the evidence status and gaps per tuple. Fixture success adds no H
  cells.
- [Camera #19](https://github.com/keesmod/ha-eufy-cam/issues/19) held HA capability
  presentation until it closed on 2026-09-11. Existing HA identifiers and public
  client methods are preserved.
- T8111/T8112 availability mapping remains unverified. Do not substitute a
  battery or HomeBase connection for that missing observation.

No publication, deployment or physical device operation is required for #19.
For package rollback, retain the preceding version and private session store.
There is no store migration. Read the exact profile below before claiming
expanded functionality.

## H3 core media, 0.7.0

[#20](https://github.com/keesmod/eufy-mega-client/issues/20) extends the existing
local-only T8030/type 18 transport with explicit LAN-derived command credentials.
The [Ready scope](https://github.com/keesmod/eufy-mega-client/issues/20#issuecomment-5630826309)
and its [command correction](https://github.com/keesmod/eufy-mega-client/issues/20#issuecomment-5630862712)
precede acceptance. Exact command evidence comes from the repository's attributed
MIT camera adapter at `b5e030b0bcf954678a877a666f6bc862ad588f4e`, especially
`Station.startLivestream`, `stopLivestream`, `startDownload`, `cancelDownload`,
`databaseQueryLatestInfo`, `downloadImage`, `databaseQueryByDate` and
`databaseCountByDate`. No vendor wire implementation changes in this story.

The additional model gate requires the exact pairs below, a T8030/type 18 owner
whose serial follows the existing T8030 branch, and a four-part numeric owner
firmware at or above 2.0.9.7. This is the existing payload branch threshold,
not a firmware-support claim. Fixtures use owner firmware 3.8.6.0 and camera
firmware 1.2.3, except the reported T8113-V, T8160-C and T8142-Z fixtures,
which use their reported camera firmware under owner firmware 3.8.7.4. Unknown,
malformed and earlier owner versions retain `EufyError` code `camera_media_unverified`.
Existing baseline model behavior is preserved. Command credentials, connections
and media stay with the actual owner.

| Model/type | Live command branch       | Stored snapshot | Live video/audio + stop | Recordings + cancel |
| ---------- | ------------------------- | --------------- | ----------------------- | ------------------- |
| T8111/1    | Generic payload           | Software        | Software                | Software            |
| T8112/4    | Generic payload           | Software        | Software                | Software            |
| T8113/8    | Generic payload           | Software        | Software                | Software            |
| T8114/9    | Generic payload           | Software        | Software                | Software            |
| T8140/14   | Generic payload           | Software        | Software                | Software            |
| T8142/15   | Generic payload, existing | Software        | Software                | Software            |
| T8160/19   | Generic payload, existing | Software        | Software                | Software            |
| T8161/23   | Generic payload           | Software        | Software                | Software            |
| T8600/24   | Professional payload      | Software        | Software                | Software            |
| T8162/26   | Generic payload           | Software        | Software                | Software            |
| T8144/49   | Generic payload           | Software        | Software                | Software            |
| T8172/89   | Outdoor pan/tilt envelope | Software        | Software                | Software            |

Generic live commands use `CMD_SET_PAYLOAD` containing
`CMD_START_REALTIME_MEDIA`, `ClientOS`, public `key` and `streamtype` 1/2 for
H.264/H.265. T8600 selects `isCameraProfessional247`, adding `camera_type=0`
and `entrytype=0`. T8172/type 89 selects the earlier
`isOutdoorPanAndTiltCamera` branch. It uses `CMD_DOORBELL_SET_PAYLOAD` with
`commandType=1000`, `accountId`, `camera_type=0`, `entrytype=0`, public
`encryptkey` and `streamtype` 0/1. This does not expose PTZ controls.
All commands retain the camera channel. The full envelopes and both codec
values are asserted independently for every tuple in
[eufycam-media.test.mjs](../test/eufycam-media.test.mjs).

Snapshots query the HomeBase's latest database covers and retrieve
`CMD_DATABASE_IMAGE`. They do not take a fresh photograph or start live media.
Missing covers keep the bounded timeout. Unsupported profiles cannot download
covers implicitly through latest-info events or retrieve recording thumbnails.
Recording calendar/list uses `CMD_DATABASE_COUNT_BY_DATE` and
`CMD_DATABASE_QUERY_BY_DATE`. List results are complete station metadata,
including known cameras whose media is unverified. Camera-bound thumbnail and
download operations check admission before opening their media connection.
Downloads use the existing H3 payload with `CMD_DOWNLOAD_VIDEO`, `filepath` and
public download key. No cipher or legacy-cloud fallback is added. The upstream
H3 TODO in vendor source is historical, not a new hardware finding.

Live stop requires a successful matching `CMD_STOP_REALTIME_MEDIA` result and
local stop on the same owner/channel. A regression fixes wrong-channel local
stop events incorrectly satisfying that condition. Cancelled starts retain
ownership until their bounded STOP outcome. Recording cancel requires matching
`CMD_DOWNLOAD_CANCEL`. Local EOF alone cannot complete a download. Recording
cleanup now removes pending source EOF listeners even when cancelled sources
never finish, and duplicate finish events do not add listeners.
The existing eight-second live cleanup and five-second download cancel bounds,
32 MiB recording limit, completion checks and no-command-replay policy remain.

The fixtures forward distinct synthetic video/audio bytes, not playable footage.
They exercise snapshots, filtered complete history, calendars, thumbnails,
download completion, cancellation, wrong channels, missing/rejected ACKs,
timeouts, late ACKs and a failing owner alongside a second active owner.
[Family lifecycle fixtures](../test/family-lifecycle.test.mjs) additionally run
each newly admitted eufyCam through duplicate events and cancelled-start cleanup.
Software success does not establish decoded or audible hardware playback.

No new H evidence is assigned. The dated T8160/T8030 baseline remains in
[COMPATIBILITY.md](COMPATIBILITY.md). At 0.7.0, #55 held physical acceptance for
each model/firmware/topology, including unavailable hardware, real video/audio,
recordings, events and restart recovery. #35 held older owners, #36 standalone
protocols, and E2/E6 were open. Release/HA integration acceptance is separate
from this software story. Version 0.7.0 was not published. This profile first
shipped in 0.10.0 and requires no session migration. Retain the prior package
and private store for rollback.
