# Changelog

## 0.30.3 - 2026-11-06

- Added the eufyCam 2C Pro `T8142-Z` on a HomeBase 3 ([ha-eufy-cam#236](https://github.com/keesmod/ha-eufy-cam/issues/236)), not yet confirmed on hardware.
- Added preset moves for the SoloCam S340 `T8170` on a HomeBase 3 ([ha-eufy-cam#229](https://github.com/keesmod/ha-eufy-cam/issues/229)), not yet confirmed on hardware.
- Added `onFrameTiming` to `startLive`, which passes on each live frame's camera timestamp ([#264](https://github.com/keesmod/eufy-mega-client/issues/264)), not yet confirmed on hardware.
- `setGuardMode` and `ensureLiveStopped` no longer close a connection attempt that another caller is making ([#270](https://github.com/keesmod/eufy-mega-client/pull/270)), not yet confirmed on hardware.
- Updated `qs` to 6.16.1, `date-and-time` to 4.7.0 and `strtok3` to 10.6.2, and corrected the key setup type docs ([#266](https://github.com/keesmod/eufy-mega-client/pull/266), [#271](https://github.com/keesmod/eufy-mega-client/pull/271), [#262](https://github.com/keesmod/eufy-mega-client/pull/262)).

Upgrade: no changes needed. Rollback: 0.30.2.

## 0.30.2 - 2026-10-26

- Added the standalone Floodlight Cam 2K `T8424` behind `experimentalStandalone` ([#142](https://github.com/keesmod/eufy-mega-client/issues/142)).
- Experimental standalone cameras that offer no command key now connect without command encryption ([#142](https://github.com/keesmod/eufy-mega-client/issues/142)).
- Added key setup diagnostics to `connectStation` with `onKeySetup` ([#142](https://github.com/keesmod/eufy-mega-client/issues/142)).

Upgrade: `StationState.commandEncryption` can now be `none`, so an exhaustive check on it needs that case. Rollback: 0.30.1.

## 0.30.1 - 2026-10-22

### Recording operation observation

- `listRecordings`, `recordingCalendar`, `recordingThumbnail` and
  `downloadRecording` accept `{ signal?, onObservation?, onProgress?, onLookup? }`
  in place of the signal. `onObservation` is called once per operation, before
  its promise settles, on success, failure, refusal and cancellation: the
  operation, whether the owner is an experimental standalone camera, whether its
  session was open, the last stage reached, the error code and `remoteCode`, and
  the elapsed time. A call that fails before the client's device transport is
  ready, such as with `authentication_required` or `client_closed`, reports
  nothing. For each query page it reports the rows requested, whether
  the answer arrived, the return code of the session's command result for that
  query, the answer's database result code and its row count. It also counts the
  database replies the session could not dispatch, with the reason and result
  code of the latest, and for a list the rows of the latest answer by class:
  own, another device, a station or path mismatch, an invalid time, another day
  and a cipher ID of any value. `onProgress` and `onLookup` report the owner's
  connection when the operation has to connect, as with `connectStation`. See
  the
  [recording operation observation](docs/API.md#recording-operation-observation-0301).
- This is for
  [ha-eufy-cam#152](https://github.com/keesmod/ha-eufy-cam/issues/152). On
  2026-10-15 "Show recordings" failed for a standalone T8410 on firmware
  2.3.2.4, one of two T8410s that stream live video, with bridge 0.8.38-beta.1 and
  client 0.30.0-beta.1. The bridge reported only `recording_unavailable`. A
  silent camera, a refusal in its command result, a reply without an inner
  command such as `{"mIntRet": -6006}` and an unparsable reply all ended the
  same way, as `device_request_timeout` after 15 seconds, because the client
  waited only for the answer event and the vendored session dropped database
  replies it could not dispatch without a trace. The query 10006 is verified
  only on a HomeBase 3, and in
  [bropat/eufy-security-client#963](https://github.com/bropat/eufy-security-client/issues/963)
  a standalone E30 never answered it. The cause on the T8410 was unknown. With
  0.30.1-beta.1 on 2026-10-16 both standalone T8410 cameras, on firmware 2.3.2.4
  and 2.3.1.6, were
  [reported](https://github.com/keesmod/ha-eufy-cam/issues/152#issuecomment-6208097780)
  acknowledging the query with command result 0 and never answering it, and a
  standalone T8410C without a microSD card rejecting it with the database
  result -1100. Recording playback on the standalone T8410 route therefore does
  not work with the current request, and standalone recordings move to
  [ha-eufy-cam#175](https://github.com/keesmod/ha-eufy-cam/issues/175), see
  below.
- Vendored P2P session: a CMD_DATABASE reply with an inner command no handler
  takes, or one whose parsing fails, now emits `database unhandled` with its
  inner command and result code when they are integers, and the reason
  `unknown_cmd` or `parse_error`. It carries numbers only, never payload text.
  The Station forwards it. The reply is still dropped as before. The session
  and Station also list, read-only, the sent commands of one name whose result
  is still pending.
- The observation carries no serial, DID, path, name or address, and every
  number is a bounded integer. A command result counts for a page only when its
  command name is that of the query, so the results of latest-info refreshes on
  a HomeBase session are not attributed to a list. Results of commands that
  were still pending when the operation began, such as a late result of an
  earlier query on the same open session, are not counted either. Without
  `onObservation` the
  operation attaches no listener.
- Observation only. The new options change no query payload, page size,
  bound (the 15-second page, 20-second connect and 60-second operation bounds),
  error code or session close after a failed or cancelled operation. The
  standalone refusals below are a separate change. A HomeBase 3 test asserts the byte-identical 10006
  payload and identical codes. The tests drive a real vendor Station for a
  synthetic standalone T8410 and a HomeBase 3 owner and feed the answers
  through the session's own parser. This is software coverage. The hardware
  results reported on 2026-10-16 are in the ha-eufy-cam#152 entry above.

### Recordings on experimental standalone cameras

- For [ha-eufy-cam#175](https://github.com/keesmod/ha-eufy-cam/issues/175), an
  experimental standalone owner, the T84A1, T8410 or T8410C behind
  `experimentalStandalone`, now reports `recordings` as
  `{ available: false, status: 'unsupported', reason: 'standalone_recordings_unverified' }`.
  Snapshot and live stay available with status `experimental`.
  `recordingThumbnail` and `downloadRecording` for one of its records fail with
  `standalone_recordings_unverified` at stage `admission`, before any
  connection or device command. A download of a record with a cipher ID still
  fails with `recording_cipher_unavailable` first. See
  [experimental standalone cameras](docs/API.md#experimental-standalone-cameras).
- No request has enough evidence to list and play recordings on a standalone
  T84xx camera. On 2026-10-16 both standalone T8410 cameras were reported to
  acknowledge the query 10006 and never answer it, and the T8410C without a
  card to reject it with -1100. The best next candidate, the app-shaped query 10017, has a public
  report on a standalone T86P2 and a code claim for the standalone T8171 and
  T817L, but no T84xx result, and a standalone owner has no playback path. The
  ranked candidates and their sources are in the
  [model matrix](docs/MODEL_MATRIX.md#standalone-recordings-outcome-0301).
- `listRecordings` and `recordingCalendar` stay owner-wide library calls
  without the standalone gate. A consumer that ignores the capability and calls
  them on a standalone owner still sends 10006 or 10008, as with 0.30.0, and
  gets the recording operation observation as for any other owner. HomeBase
  owners, their payloads, code paths and capabilities are unchanged by this
  change. It sends no new device request and leaves the vendored code
  unchanged. On a standalone camera, the opt-in probe below is the only new
  request of 0.30.1.
- The standalone tests assert the unavailable recordings for the T84A1, T8410
  and T8410C next to a HomeBase camera in the same transport that keeps them.
  The observation tests assert the standalone thumbnail and cipher-less download
  refusals at `admission` without an image or database request, and the
  invalid thumbnail validation is tested on a HomeBase 3 owner. The HomeBase 3 test
  of the byte-identical 10006 payload is unchanged. This is software coverage.

### Standalone recording probe

- For [ha-eufy-cam#178](https://github.com/keesmod/ha-eufy-cam/issues/178),
  `probeStandaloneRecordings(id, { signal?, onProgress?, onLookup? })` sends one
  read-only `CMD_DATABASE_QUERY_LOCAL` 10017 query on `history_record_info` to
  an experimental standalone camera, the T84A1, T8410 or T8410C behind
  `experimentalStandalone`, and resolves with a recording operation observation
  with `operation: 'probe'`. It asks for the newest page of at most 20 records
  of today, the process's local date, on `mChannel` 0 and frame channel 0, with
  `start_time` `"0"` and without `device_info` or `res_unzip`. It is the
  app-shaped candidate 1 in the
  [model matrix](docs/MODEL_MATRIX.md#standalone-recordings-outcome-0301). See
  the [standalone recording probe](docs/API.md#standalone-recording-probe-0301).
- A HomeBase, a camera behind a HomeBase, an unknown ID and a standalone camera
  without `experimentalStandalone` fail with `operation_outside_hardware_scope`
  before any connection or request. After admission the promise resolves with
  the observation for every outcome. One call sends at most one 10017 request.
  When the owner is not connected, its connection first sends the vendored
  latest-info query 10013, as at every connect. A latest-info answer that names
  a camera's crop picture then makes that connection request the picture as a
  snapshot cover, unless it is already the cached cover. The busy check, the
  connection with `onProgress` and `onLookup`, the 15-second answer bound and
  the 60-second operation bound are those of the other recording operations. A
  failure after the connection was requested closes the owner's session, as
  for the other operations, except `connection_busy`, which leaves the other
  attempt's session alone. An answer keeps it open, also one with a non-zero database result,
  which is reported as `history_rejected` with that result in `remoteCode`. A
  list closes the session after `history_rejected`.
- The observation counts the answer's records and their row classes, without
  identifiers. It does not count unhandled database replies with inner command
  10013, so a reply that names the latest-info query the Station sends at
  connect is not attributed to the probe, also when it fails to parse. Every
  other unhandled reply counts, as for the other operations. That includes a reply without a readable inner command, whichever
  query it answers.
- The probe itself creates no recording ID and sends no 10006, 10008, image or
  download request. The recordings capability of standalone cameras stays
  unavailable with `standalone_recordings_unverified`.
- Vendored Station: the client addition `databaseQueryLocalNewest` builds the
  request. Like its siblings it throws `NotSupportedError` for a station whose
  command set lacks the query, and the probe then reports
  `device_request_failed` at stage `query` without a page. The vendored
  `databaseQueryLocal` builder and the 10017 reply parser are unchanged.
- The probe leaves HomeBase owners, their payloads, code paths and
  capabilities unchanged. The HomeBase 3 test of the byte-identical 10006 payload is unchanged. The new
  tests drive a real vendor Station for a synthetic standalone T8410 and assert
  the exact request and its key set, an empty page, rows by class, a non-zero
  database result that keeps the session open, silence with ACK 0, a negative
  ACK, an unparsable 10013 reply that is not counted, a connect whose 10013
  precedes the probe's request, a failed connect with
  progress and lookup, `station_busy`, cancellation, the `NotSupportedError`
  path and the refusals before any request. This is software coverage. No probe
  result has been reported on hardware yet.

### Standalone T84A1 motion and person events

- For [ha-eufy-cam#185](https://github.com/keesmod/ha-eufy-cam/issues/185), a
  standalone T84A1 behind `experimentalStandalone` now delivers motion and
  person detection events from its pushes. A push that names an experimental
  standalone owner as `device_sn` or `station_sn` is admitted only when the
  exact profile allows standalone events, which only `T84A1`/151 does, the
  camera is available, `device_sn` and `station_sn` both name it, the push type
  is its inventory device type 151 and `event_type` is the number 3101 (motion)
  or 3102 (person). A push over the camera's open session carries its
  `msg_type` as type, so it is admitted only if the camera sends 151 there,
  which no capture has shown. See
  [standalone events and push observation](docs/API.md#standalone-events-and-push-observation-0301).
- Every other push for a standalone owner stays refused: guard mode, alarm,
  microSD, undecoded notifications, other detections, other push types and
  pushes that name another serial. T8410 and T8410C pushes are refused as
  before, now counted.
- No standalone push reaches the vendored station or camera push handler, so
  the camera gets no guard mode, alarm or microSD state from a push, and no
  event image is loaded. No event sends the latest-info query 10013, issues a
  command or opens or wakes a connection, also when the camera's session is
  already open. Events carry no new image, and person recognition stays
  `unidentified`. A standalone camera emits no device-sourced detection.
- The new getter `standalonePushStatus` counts these pushes with numbers only:
  arrived, admitted, refused by reason, cloud or local source, and histograms of
  the event code and push type, bounded to 16 numeric keys each. It carries no
  serial, DID, address, name, URL, path, timestamp or image. The types
  `StandalonePushObservation`, `StandalonePushRefusal` and
  `StandalonePushSource` are exported.
- This change leaves HomeBase pushes, their events, handlers and snapshot
  refresh unchanged, and never counts them. The tests cover an admitted motion and person push with the
  session closed and open, every refused push type, pushes naming another
  serial, local pushes shaped as the vendored session emits them, the T8410
  and T8410C refusals, unchanged HomeBase events
  and the client-level wiring, with synthetic rows and a stubbed station. This
  is software coverage. No standalone T84A1 push has been captured on hardware
  yet.

### Dependency maintenance

- The runtime dependency `protobufjs` moves from `^8.0.0` to `^8.8.1`, locked
  at 8.8.1 instead of 8.8.0. The vendored push client uses it for the FCM
  checkin and the MCS messages of its push connection. 8.8.1 rejects a length
  prefix of a string, bytes, embedded message or packed field that does not fit
  a signed 32-bit integer with `invalid length encoding`, where 8.8.0 kept its
  low 32 bits. Messages from a standard encoder decode as before. A push message
  that fails to decode closes the push connection, as other malformed messages
  already did. The other fixes of 8.8.1 concern string escapes and enum JSON
  names in `.proto` files, which the client's two `.proto` files do not use.
- The lockfile moves the transitive `strtok3` from 10.3.5 to 10.4.0. It is a
  dependency of `file-type`, which `image-type` uses in the vendored
  `getImage`. The client's cloud provider refuses that image download with
  `operation_outside_hardware_scope` before `image-type` reads any byte, so no
  image reaches `file-type` or `strtok3` in this client. 10.4.0 adds an opt-in
  buffer size limit that is off by default, validates token lengths and
  positions and fixes abort signal handling.
- Development only: `@types/node` 24.19.2 and `prettier` 3.9.10.
- These are maintenance updates, not a security fix. No published advisory
  covers protobufjs 8.8.0 or strtok3 10.3.5. These updates need no change in
  `src`, `vendor` or the public API. No hardware run is needed for them,
  because well-formed push messages take the same code path and no image
  reaches `strtok3`.

### Video Doorbell 2K T8210 and T8210C

- Admit exactly `T8210` and `T8210C`, each with device type 7, under a
  HomeBase 3. Both are the battery-powered Video Doorbell 2K that Eufy now also
  sells as Video Doorbell S220. `T8210C` is a variant of `T8210`. They use the
  `BatteryDoorbellCamera` adapter, H3 topology and the additional-H3 media
  policy of the T8214, T8224 and T8223 doorbells. Media needs the actual T8030
  owner on firmware 2.0.9.7 or later. Live start sends the same generic
  `CMD_SET_PAYLOAD` envelope as T8224 and T8223. Stored snapshots, recordings,
  download and cancellation use the same HomeBase commands as the other H3
  doorbells. Battery, availability and motion, person and ring events use the
  existing observed properties and pushes. The vendored adapter selects all of
  this from type 7 and is unchanged.
- This rests on public evidence from other clients. Eufy's HomeBase 3
  compatibility page lists T8210 as compatible. A 2023 inventory shows `T8210`
  with type 7 under a T8030, and a public Mega inventory shows `T8210`/7 with
  category `eufy_security` under a HomeBase 2. Public diagnostics show a
  doorbell received as `T8210C` with type 7 under a HomeBase 2, and two public
  reports describe a T8210C under a T8030 without its received model.
  [ha-eufy-cam#198](https://github.com/keesmod/ha-eufy-cam/issues/198) reports a
  T8210 under a HomeBase 3 that the integration does not list, without its
  received model and type. It is not verified which of the two pairs that row
  carries, or that it carries either.
- `T8212`, which stays a type 7 candidate in the model matrix, the type 16
  candidates `T8220`, `T8221` and `T8222`, other suffixes such as `T8210P` and
  other types for `T8210` or `T8210C` remain `unsupported_device`. No prefix or
  type-only admission is added.
- Synthetic tests cover discovery, state, events, the media commands, confirmed
  live stop, recording cancellation and the owner and firmware rejections for
  both pairs, as for the other H3 battery doorbells. This is software coverage.
  No T8210 or T8210C hardware result exists for this client.

Upgrade: the observation is additive and optional. The four recording calls take
the new options object in place of the signal, a plain signal keeps working, and
consumers that pass neither see no change from it. The types
`RecordingOperation`, `RecordingOperationStage`, `RecordingQueryPage`,
`RecordingRowClasses`, `RecordingObservation` and `RecordingOperationOptions`
are exported. `RecordingOperation` names the four recording calls and
`'probe'`, the operation of `probeStandaloneRecordings`, which sends its
request only when a consumer calls it. With `experimentalStandalone` set, an
experimental standalone camera, the T84A1, T8410 or T8410C, now reports
recordings as unavailable with `standalone_recordings_unverified`, and its
thumbnail and download fail with that code. A download of a record with a cipher ID fails with
`recording_cipher_unavailable` first. HomeBase cameras keep their recordings
capability. The
`standalonePushStatus` getter and its three types are additive, with no new
option. Standalone T84A1 events arrive only with `experimentalStandalone` and
running events. A structural implementation of `SecurityModule` needs the new
`probeStandaloneRecordings` method and `standalonePushStatus` getter. A
`T8210`/7 or `T8210C`/7 row that was `unsupported_device` now becomes a battery
doorbell camera. Under a HomeBase 3 on firmware 2.0.9.7 or later it gets
experimental H3 media. Under another parent, such as a HomeBase 2, it is listed without media
as `unsupported_station`, and an empty or self parent gives
`invalid_device_relationship`. The dependency updates need no code change. The
published package carries no lockfile. 0.30.1 requires `protobufjs` 8.8.1 or a
later 8.x. A consumer resolves `strtok3` through its own lockfile within the
`^10.3.4` range of `file-type`, also with 0.30.0.
Rollback: 0.30.0, pass the signal alone again and remove calls to
`probeStandaloneRecordings` and reads of `standalonePushStatus`. That also
restores the earlier recordings capability of standalone cameras, whose lists
did not work on the reported cameras, and the refusal of every standalone push.
It also rejects `T8210`/7 and `T8210C`/7 again as `unsupported_device`.
0.30.0 declares `protobufjs` `^8.0.0`, so a consumer can keep the updated
lockfile with it or restore its previous one.

## 0.30.0 - 2026-10-15

### Station lookup observation

- `connectStation(id, { onLookup })` reports what the local lookup of a
  connection attempt saw, once per attempt that reached the `lookup` stage, when
  it resolves, fails or is cancelled: the rounds and broadcast targets sent,
  whether the socket accepted broadcasts, failed sends, the datagrams received
  and the lookup replies by class. A reply carries the station's own DID, the
  DID of another device in the inventory, a DID outside the inventory, or a near
  match of the own DID that differs only after a NUL byte, in surrounding
  whitespace, in case or in the format of its number. The observation also gives
  the class of the first reply from the inventory address, whether that address
  lies in one of the host's subnets and whether another inventory row has the
  same address. See the
  [station lookup observation](docs/API.md#station-lookup-observation-0300).
- This is for
  [ha-eufy-cam#152](https://github.com/keesmod/ha-eufy-cam/issues/152), where a
  standalone T8410 on firmware 2.3.1.6 ended its connections at the `lookup`
  stage with `inventoryAddress: true` while a T8410 on 2.3.2.4 connected. Until
  now a reply with another DID was dropped without a trace, so a camera that
  sent nothing could not be told apart from one whose reply was not accepted.
  With this observation a failed run showed only replies from other devices in
  the account. On 2026-10-15 that camera was reported streaming. Why no reply
  from it arrived in that run is not known.
- The observation carries no DID, address, port, serial or interface name, and
  every count is bounded. Before an attempt starts its session, the client hands
  the P2P session the DIDs of the inventory's other devices and stations. The
  session keeps its own copy of them, which never leaves the process. The
  session compares the DID of each lookup reply with the station's own DID and
  with those when the reply arrives, and then only counts it. The DID of a
  replying device is never stored or reported. Only the counters are kept, also
  across a close, until the session starts its next connection, so a close the
  attempt did not make still leaves its counts for `onLookup`.
- Observation only. The lookup's targets, timing and retries, the DID it
  accepts, the socket and the connection stages are unchanged, with and without
  `onLookup`.

### Experimental standalone T8410C

- The opt-in client option `experimentalStandalone` now also admits a standalone
  Indoor Cam Pan&Tilt 2K `T8410C`/31 with an empty or self parent, for
  [ha-eufy-cam#168](https://github.com/keesmod/ha-eufy-cam/issues/168). The
  reporter of ha-eufy-cam#152 has one on firmware 3.3.4.4 without a HomeBase.
  With 0.30.0-beta.1 and the option on, it was discovered with a complete
  descriptor but stayed `standalone_transport_unverified` with no session
  attempt, because only the T84A1 and T8410 profiles allowed the route. The same
  reporter reported both of their standalone `T8410` cameras streaming live on
  that route, on firmware 2.3.2.4 and 2.3.1.6. This is not independently
  reproduced.
- With the option the T8410C becomes its own P2P owner on the existing local
  lookup and LAN-derived command key, with experimental snapshot, live and
  recordings on its own session, as for the T8410. Live uses the same generic
  Indoor start envelope, because the camera's own station is not a HomeBase.
  Whether the 3.3.x firmware line accepts the LAN-derived command key, answers
  the gateway information request and accepts this start is not known. No
  standalone T8410C has used the route yet.
- With the option on, a consumer that connects experimental owners at
  discovery, as the ha-eufy-cam bridge does, now also opens a local session to
  each standalone T8410C there. A camera that does not answer adds up to the
  20-second connect bound to that discovery.
- Without the option nothing changes. A T8410C under a HomeBase keeps its H3
  relationship, media and live branch, also with the option. Other models,
  suffixes such as `T8410C21` and other types stay unverified or unsupported.
  Guard mode, pushes, detection events and cipher downloads stay refused on the
  route. Admitting the T8410C changes only its profile flag and adds no API,
  type or vendor change of its own.
- The standalone tests run the T8410 cases for the T8410C too, with synthetic
  rows. The HomeBase T8410C tests are unchanged. This is software coverage.
  Hardware results for the standalone T8410C are pending.

Upgrade: additive and optional. `StationConnectOptions` gains `onLookup`, and
the type `StationLookupObservation` is exported. Consumers that do not pass it,
older ones included, see no change from it, and `connectStation(id, signal?)`
is unchanged. With `experimentalStandalone` already set, a standalone T8410C now
reports `transport: 'experimental'` instead of
`reason: 'standalone_transport_unverified'`. Rollback: 0.29.2, and drop
`onLookup`. To keep a standalone T8410C off the route without a rollback, turn
the option off, which also takes the T84A1 and T8410 off it.

## 0.29.2 - 2026-10-12

### eufyCam 3 and Indoor Cam Pan&Tilt 2K model codes

- Admit exactly `T8160-C` with device type 19, reported under a HomeBase 3 on
  [ha-eufy-cam#149](https://github.com/keesmod/ha-eufy-cam/issues/149). It uses
  the T8160 Camera adapter and H3 topology with the additional-H3 media policy,
  not the established T8160 route. The existing owner and firmware checks apply.
  Its reported firmware 1.5.8.6 differs from the T8160 line, so T8160 hardware
  results do not transfer to it.
- Admit exactly `T8410C` with device type 31, the Indoor Cam Pan&Tilt 2K, with
  the T8410 H3 policy without the experimental standalone flag: the
  `IndoorCamera` adapter, `h3-or-standalone` topology and additional-H3 media.
  This rests on public evidence. Eufy's HomeBase compatibility guide lists
  T8410C as supported on HomeBase 3, and public inventories show T8410C with
  type 31 under a T8030. The two type 31 rows in ha-eufy-cam#149 could not show
  their model, so it is not verified that they carry exactly `T8410C`. The
  experimental standalone route that 0.29.1 opened for a standalone `T8410`
  stays off for T8410C, also with `experimentalStandalone`. The 0.29.1 entry
  calls that `T8410` an Indoor Cam Pan & Tilt 2K. Eufy's HomeBase guide names
  T8410 the Indoor Cam E220 and T8410C the Indoor Cam Pan&Tilt 2K, and owners
  use Pan & Tilt names for both. The received model code, not the product name,
  decides which profile applies.
- Other suffixes, twins such as `T8160C` and `T8410-C`, lower case and
  mismatched types remain `unsupported_device`. No prefix or type-only
  admission is added.
- The bounded `deviceModel` of an `unsupported_device` issue and
  `context.parentModel` now also show catalogue codes with one to three
  unhyphenated characters, such as `T8410C`, `T8W11C` and `T8419N`, up to eight
  characters. The hyphen form such as `T8113-Z` is unchanged. Serial numbers and
  free text still never match, and nothing is trimmed. A consumer that
  revalidates the value with the older pattern omits these codes until it
  adopts the same bound.
- Synthetic tests cover discovery, state/events and the existing media commands
  for both pairs, including confirmed live stop, recording cancellation, the
  owner and firmware rejections and the widened diagnostic. Discovery and the
  media and lifecycle fixtures use the reported camera and owner firmware. The
  state/events tests use synthetic firmware. This is software coverage. Hardware
  results for both models are pending.

Upgrade: no configuration, API or session migration. A `T8160-C`/19 or
`T8410C`/31 row that was `unsupported_device` now becomes a camera, and
diagnostics can carry an unhyphenated model code where they omitted the field.
Rollback: 0.29.1. No new protocol or legacy security-cloud fallback is added.

## 0.29.1 - 2026-10-12

### Experimental standalone T8410

- The opt-in client option `experimentalStandalone` now also admits a standalone
  Indoor Cam Pan & Tilt 2K `T8410`/31 with an empty or self parent, for
  [ha-eufy-cam#152](https://github.com/keesmod/ha-eufy-cam/issues/152). Its
  reporter has two such cameras without a HomeBase. On 0.29.0 they were
  discovered with a complete descriptor but stayed
  `standalone_transport_unverified` with no session attempt, because only the
  T84A1 profile allowed the route. With the option the camera becomes its own
  P2P owner on the existing local lookup and LAN-derived command key, with
  experimental snapshot, live and recordings on its own session, as for the
  T84A1. Live uses the existing generic Indoor start envelope, because the
  camera's own station is not a HomeBase. No physical standalone camera has
  used the route yet.
- With the option on, a consumer that connects experimental owners at
  discovery, as the ha-eufy-cam bridge does, now opens a local session to each
  standalone T8410 there. A camera that does not answer adds up to the
  20-second connect bound to that discovery.
- Without the option nothing changes. A T8410 under a HomeBase keeps its H3
  relationship, media and live branch, also with the option. Other Indoor
  models, `T8410C` and other types stay unverified or unsupported. Guard mode,
  pushes, detection events and cipher downloads stay refused on the route. The
  only runtime change is the T8410 profile flag, with no API, type or vendor
  change.

Upgrade: no configuration, API or session migration. With the option already
set, a standalone T8410 now reports `transport: 'experimental'` instead of
`reason: 'standalone_transport_unverified'`. Rollback: 0.29.0, or turn the
option off.

## 0.29.0 - 2026-10-10

### Experimental standalone T84A1

- New opt-in client option `experimentalStandalone`, off by default. With it, a
  standalone Wall Light Cam S100 `T84A1`/151 becomes its own P2P owner on the
  existing local lookup and LAN-derived command key. Snapshot, live and
  recordings report `experimental` and use the camera's own session. This is
  for [#142](https://github.com/keesmod/eufy-mega-client/issues/142) and the
  [ha-eufy-cam#66](https://github.com/keesmod/ha-eufy-cam/issues/66) reporter's
  offer to test. No physical standalone camera has used it yet. No cloud DSK,
  cipher or legacy security-cloud call is added. Guard mode, pushes and
  detection events are not admitted on this route, and live always uses the
  camera's one session. A recording download that would need a cloud cipher
  fails with `recording_cipher_unavailable` before any device command.
- Every standalone relationship has a new `descriptor` with presence booleans
  for the row's P2P device ID, license, administrator user and private LAN
  address. Values never leave the library.
- A P2P session whose row has no `app_conn` starts with no cloud addresses
  instead of failing during creation. Local sessions do not use them.
- A malformed `params` value in an inventory row now means no inventory LAN
  address instead of an error.

Upgrade: no configuration or session migration. Without the option, standalone
results only gain the `descriptor` field, and the two robustness fixes above
apply to every row. TypeScript: the new `standalone` relationship has
`transport` instead of `reason`, so check `'reason' in relationship` before
reading it. Rollback: 0.28.2.

## 0.28.2 - 2026-10-09

### eufyCam 2C model variant

- Admit exactly `T8113-V` with device type 8, reported under a HomeBase 3 on
  [ha-eufy-cam#66](https://github.com/keesmod/ha-eufy-cam/issues/66#issuecomment-6083775017).
  It uses the same Camera adapter, actual H3 owner and snapshot/live/recording
  policy as `T8113` and `T8113-Z`. Other suffixes and mismatched types remain
  unsupported. The existing owner and firmware checks still apply.
- Synthetic tests cover discovery, state/events and the existing media commands,
  including confirmed live stop and recording cancellation. This is software
  coverage. The reporter's T8113-V firmware 3.0.7.8 behind T8030 firmware 3.8.7.4
  still needs post-upgrade hardware results.
- Record that the same reporter now has working snapshots, live and recordings
  on T8213 and T8161. Standalone T84A1 media remains blocked by the missing
  authentication/transport route in #142.

Upgrade: no configuration or session migration. Rollback: 0.28.1. No new protocol
or legacy security-cloud fallback is added.

## 0.28.1 - 2026-10-08

### Dependency maintenance

- The lockfile moves `uint8array-extras` from 1.5.0 to 1.6.0. It is a
  dependency of `file-type`, which `image-type` uses when `getImage` detects
  the type of a cloud image. 1.6.0 also accepts an `ArrayBuffer` in every
  method that takes bytes.
- Development only: `@types/node` 24.19.0, `undici-types` 7.24.6 and
  `prettier` 3.9.9.
- The declared dependencies, `src`, `vendor` and the public API are unchanged.

Upgrade: nothing to change. The published package carries no lockfile, so a
consumer resolves `uint8array-extras` through its own lockfile and gets 1.6.0 by
updating that lockfile, also with client 0.28.0. Rollback: 0.28.0.

No hardware run is needed, because no protocol, command or media path changes.

## 0.28.0 - 2026-10-05

### Wired Cam C31

- Discovery admits `T817L` with device type `10031`, the Wired Cam C31, in the
  indoor family with the additional-H3 media policy. The reporter on
  [ha-eufy-cam#136](https://github.com/keesmod/ha-eufy-cam/issues/136) receives it
  under a HomeBase 3 on firmware 3.8.5.2 with camera firmware 2.1.0.3, and earlier
  versions reject it as `unsupported_device`. Only this exact pair is added.
  `T817L121`, lower case and other types stay unsupported.
- Type 10031 was not in the vendored device catalogue. It is added as
  `DeviceType.WIRED_CAM_C31` with the motion, person, pet, vehicle, sound and
  crying detection states, and with the live start, live stop, recording download
  and download cancel commands only. Pan and tilt, presets, talkback, alarm and
  settings are not registered. Battery and availability stay null, as for the
  other mains-powered indoor cameras. `Device.isCamera()` includes the type, so
  a push the HomeBase 3 relays for the C31 is read like those of the other
  HomeBase cameras.
- Under a HomeBase 3 the live start uses the existing HomeBase-controlled S350
  branch: `CMD_SET_PAYLOAD` with `CMD_START_REALTIME_MEDIA`, the camera's
  `mChannel`, `camera_type`, `entrytype`, both account fields and the public key.
  A separate MIT-licensed gateway reports live view and snapshots for this camera
  through a HomeBase 3 with the same fields. Stop, stored snapshots, recordings
  and cancellation use the unchanged H3 paths. Whether the C31 acknowledges the
  plain H3 stop is not yet verified. See
  [INDOOR.md](https://github.com/keesmod/eufy-mega-client/blob/main/docs/INDOOR.md#wired-cam-c31-0280).
- A C31 that is its own station, without a HomeBase, is recognized as
  `standalone_transport_unverified` and gets no media. Standalone transport stays
  in #36. The HomeBase Mini stays in #35.

### Dependency update

- The lockfile moves the transitive `http-cache-semantics` from 4.2.0 to 4.3.0
  for the high advisory
  [GHSA-ch52-4w7c-c8xp](https://github.com/advisories/GHSA-ch52-4w7c-c8xp), which
  failed the required audit. It reaches the client through `got` and
  `cacheable-request`. The client uses `got` only for the push service, without a
  response cache, so the affected cache handling was not exercised. No direct
  dependency or range changes.

Upgrade: no identifier, session or option change. Consumers see one more admitted
camera when a C31 is present. Rollback: retain the previous package and lockfile
and use 0.27.0, which rejects the C31 again. Its lockfile also brings back
`http-cache-semantics` 4.2.0 with the advisory above. No mower behavior changes.

## 0.27.0 - 2026-09-29

### Mower charger contact

- `mowers.queryCloudState(id, signal?)` also returns `charger`, the E15's
  charger contact from DP 108 in the same cloud record: `{ state: 'reported',
connected }`, `missing` or `invalid`. `connected` is field 2 of the battery
  status message, which the official app's own decoder reads as its charger
  connection. It is true while the mower stands on its station's contacts and
  false once it has left them. It is the first confirmed reading that
  separates a rest at the station from a stop on the lawn, where the idle
  mission status, DP 5 and hibernation are the same.
- The definition is internal to the cloud reading. `E15_TELEMETRY_DEFINITIONS`,
  `MowerTelemetryDefinition` and `MowerTelemetry` are unchanged: the E15's
  local status replies do not carry DP 108, and no DP 108 LAN report was part
  of the evidence.
- One owner-requested window on 2026-09-29 read the contact connected in every
  sample of four rests at the station, the longest 29 minutes in hibernation,
  and not connected in every sample of three stops of about twenty minutes on
  the lawn, cleared on three departures and set on three arrivals, with the
  app's display as correlation. See the
  [charger contact receipt](docs/research/E15_CHARGER_CONTACT_2026-09-29.md).

### Dependency update

- The runtime dependency `date-and-time` moves from `^4.3.0` to `^4.6.0`,
  locked at 4.6.0 instead of 4.5.2. The client only calls its `parse` and
  `format` through CommonJS `require`, for the dates in station database
  queries such as recording lists. 4.6.0 rewrites the built-in formatter and
  parser as object literals and adds a CommonJS default export to its locale,
  numeral and time zone modules, which the client does not load. For the two
  patterns the client uses, `YYYYMMDD` and `YYYY-MM-DD HH:mm:ss`, both versions
  return the same dates, invalid dates and errors. The development dependencies
  `@types/node` 24.13.6 and `prettier` 3.9.8 are not part of the package.

Upgrade: consumers that compare a whole `MowerCloudStateReading` receive the
new `charger` field. A custom `MowerModule` test double that returns cloud
readings adds it. Keep the reading a cloud cache: apply the same receipt-age
bound as for cloud activity and never use it to confirm a command. Rollback:
retain the previous package and lockfile and use 0.26.0, which ignores DP 108
and locks `date-and-time` 4.5.2. No E18 support claim is added.

Use the compiled versioned 0.27.0 tarball and its verified integrity from the
GitHub release. The change is verified in two ways:

- In software, by CI and synthetic tests of the charger decoder, the cloud
  reading, every missing and invalid form, the unchanged local telemetry and
  registry, and the consumer types, and by the unchanged date results of
  `date-and-time` 4.6.0 for the client's two patterns.
- On hardware, outside the library: the cloud's data point request, sampled
  every two seconds in the window of 2026-09-29, carried the contact as the
  receipt describes. The same day one read-only comparison found the same DP
  108 value, connected, in the record of the request this release makes,
  `tuya.m.device.get`, while the mower rested at the station.

The charger contact has not yet been read through the library itself on
hardware. The mower bridge that pins this release is the next check, in
keesmod/eufy-robomow-ha#86.

## 0.26.0 - 2026-09-28

### Reported eufyCam 2C and Floodlight Cam 2K models

- Discovery admits `T8113-Z` with device type `8` under a HomeBase 3 with the
  same eufyCam adapter, H3 topology and snapshot, live and recording policy as
  `T8113`. The reporter on
  [ha-eufy-cam#129](https://github.com/keesmod/ha-eufy-cam/issues/129) receives
  three eufyCam 2C cameras as `T8113-Z` and reports snapshots, live view and
  HomeBase recordings working with this exact entry added locally. Only this
  exact model code is added. Other suffixes stay unsupported.
- `T8424` with device type `39`, the Floodlight Cam 2K, is recognized as a
  standalone floodlight. The same report shows it as its own station, also after
  it was assigned to a HomeBase 3, which stores its video only. It therefore
  reports `standalone_transport_unverified` instead of `unsupported_device` and
  gets no media. Under a HomeBase 3 parent it reports `unsupported_station`.
  Standalone transport remains blocked in #142.
- Discovery diagnostics report a received model code with a short suffix, such
  as `T8113-Z`, instead of omitting it. Serials and free text still never match.

### Station lookup across every LAN interface

- The local lookup for a station still asks the inventory's LAN address first,
  as it was when the station's session was created. When that address stays
  silent for a second, every retry also goes to the directed broadcast address
  of each external IPv4 interface, at most 16 and skipping /31 and /32
  interfaces. Without an inventory address, or an address the station completed
  a session handshake from earlier, the first lookup already goes to those
  broadcasts. The API
  documentation covers hosts without any broadcast address. Earlier versions
  retried only the inventory address, or broadcast only on the first interface
  Node listed, which on a Docker host can be a container bridge rather than the
  HomeBase's LAN. A stale inventory address or the wrong interface could
  therefore end every connection in `device_request_timeout`.
- Only an answer carrying the station's own DID ends the lookup. Earlier, any
  device answering a lookup, such as a standalone camera on the same LAN, ended
  it without a connection.
- `connectStation(id, { signal?, onProgress? })` reports how far a connection
  got: `lookup` with `inventoryAddress`, `station_found`, `session_open` and
  `encryption_ready`, each once with `elapsedMs`. The form
  `connectStation(id, signal?)` is unchanged. See the
  [station connection stages](docs/API.md#station-connection-stages-0260).
- This targets the HomeBase 3 connection failure reported on
  [ha-eufy-cam#130](https://github.com/keesmod/ha-eufy-cam/issues/130), which
  ends in `device_request_timeout` on a Docker host with firmware 3.8.7.4. The
  maintainer's HomeBase 3 on the same firmware connects with 0.21.0, so the
  firmware alone does not explain it. The cause on that installation is not
  confirmed. The stages show where a remaining failure stops.

Upgrade: no identifier, session or option change. Consumers that pass an
`AbortSignal` to `connectStation` keep working. Rollback: retain the previous
package and lockfile and use 0.25.2, which rejects both models again and
restores the earlier lookup. No mower behavior changes.

## 0.25.2 - 2026-09-27

### Renew the Home session before map provisioning is refused

A map session needs more than 65 seconds of validity at the start of a demand,
and provisioning caps it by the Home session's expiry. A Home session with at
most 65 seconds left still reported `connected`, so a consumer did not renew it
and every provisioning call failed with `mower_map_invalid_provisioning` until
the session expired. Offline boundary cases reproduce this. A live provisioning
failure in the 2026-09-26 E15 window recovered only after renewal and the next
idle refresh. Its session lifetime was not captured, so that link remains an
inference.

- With `mowers.home.mapProvisioning: true`, the Home session lapses once at
  most 65 seconds plus one request timeout and a five-second margin remain.
  The timeout covers the RTC read and the margin the acquisition's own
  revalidation. `connected` then reports `false` and `authState`
  `disconnected`, so the consumer renews through `connect()` before
  provisioning. An explicit connect no longer restores a persisted session
  inside that reserve, also when its restore check carries it there. It logs
  in afresh and keeps the existing opaque device identity.
- With the default 15-second request timeout the reserve is 85 seconds of the
  one-hour reuse window, and at most 130 seconds with the 60-second maximum.
  Without map provisioning the reuse window is unchanged.
- A request the library refuses because of the reserve leaves the device
  bindings in place. Open leases keep running until the session expires, the
  server revokes it or a renewal starts. Provisioning still never logs in or
  retries by itself, and RTC expiry keeps its existing bound.
- Synthetic regressions pin both sides of the boundary while connected and on
  restore, a restore check that crosses it, a cloud read that ends inside it
  while provisioning runs, the refused provisioning without an RTC request and
  the unchanged window without map provisioning. No hardware run has confirmed
  the renewal yet. That remains part of keesmod/eufy-robomow-ha#8.

Upgrade: no API, persisted-session or option change. A consumer that renews on
`connected: false`, such as mower bridge 0.13.0, renews from 85 seconds before
the local expiry with map provisioning and the default request timeout.
Rollback: retain the previous package and lockfile and use 0.25.1, which
reintroduces the near-expiry refusal. No E18 support claim is added.

## 0.25.1 - 2026-09-26

### Keep the native map carrier alive through cancellation

The unpublished 0.25.0 candidate adds typed cloud mower activity and stricter
map cancellation. Its dock trial exposed a second failure: a ten-second demand
cancelled successfully, while a thirty-second demand lost the carrier before
receiving its cancellation reply.

- Send the original carrier's empty heartbeat every second after the verified
  handshake, through the bounded cancellation window. The timer belongs to the
  acquisition lifetime and is cleared during cleanup. This is transport
  maintenance, with no mower movement, settings write or command retry.
- Keep strict cancellation correlation and stop reuse after uncertain
  cancellation. A downloaded map alone still does not prove a clean demand.
- The protocol is derived from the hash-pinned original vendor artifact and
  owned read-only E15 traffic. Runtime code and regression fixtures are
  independently authored. No Android or vendor binary is a runtime dependency.

This version includes the cloud API and cancellation changes listed under
0.25.0, which was not published. Upgrade consumers from 0.24.0, preserve private
state and retain the previous package and lockfile for rollback. Moving-map
acceptance remains in keesmod/eufy-robomow-ha#8. No E18 support claim is added.

## 0.25.0 - 2026-09-26

### Mower cloud activity and map cancellation

- `mowers.queryCloudState(id, signal?)` reads typed mission activity and work
  parameters from one authenticated, device-bound cloud record. The source and
  receipt time are explicit. A cloud receipt does not establish device freshness
  or physical dock arrival. The API sends no mower command and does not feed
  command confirmation. `queryWorkParameters` remains compatible.
- Soft cancellation of a map stream drains and acknowledges in-flight file
  traffic without parsing or publishing new files while awaiting the correlated
  cancellation reply. A terminal packet from an incomplete file can no longer
  prevent that reply from being read. Cancellation still requires its matching
  acknowledgement. Failures expose only a bounded diagnostic category.
- Synthetic regressions cover cloud lifecycle, binding, typed status, unchanged
  command evidence and map cancellation with an incomplete file. A read-only
  docked E15/T2880 observation confirmed that the existing device-get route
  carries both fields. The moving-map acceptance in keesmod/eufy-robomow-ha#8
  remains open. No E18 support claim is added.

Upgrade: add `queryCloudState` to custom `MowerModule` test doubles. Consumers
must keep cloud activity separate from LAN reports and command confirmation,
apply a receipt-age bound, and stop automatic acquisition after unconfirmed
cancellation. No persisted-session migration is needed. Rollback: retain the
previous package and lockfile, use 0.24.0 and disable continuous map acquisition
when cancellation is unconfirmed. These changes do not publish a product or
establish completed hardware acceptance.

## 0.24.0 - 2026-09-25

### Private mower map provisioning

- `mowers.home.mapProvisioning: true` enables
  `client.mowers.provisionMapSession(id, signal?)`. One current RTC read
  produces private provisioning for the discovered mower from its Home/Tuya
  session. The library checks account/device binding, regional MQTT endpoint
  and expiry. There is no automatic login, retry, acquisition or physical
  command in this call. The opt-in defaults to off.
- The existing private session store gains derived MQTT credentials. On
  explicit connect, an older session without these credentials is refreshed
  once while preserving the mower's opaque identity.
- `MapSessionProvisioning.mqttHeader` becomes optional. Without it, each
  acquisition creates a fresh original-SDK 2.3 header. Existing explicit
  headers keep their historical behavior. The implementation uses original
  vendor protocol observations, with no helper or Android runtime dependency.
- Synthetic tests cover lifecycle, identity, expiry, privacy, session reuse
  and the generated header. Fresh hardware acceptance remains open in
  keesmod/eufy-robomow-ha#8. No E18 claim is added.

Upgrade: add `provisionMapSession` to custom `MowerModule` test doubles, enable
the option only for the intended map owner, and pass fresh provisioning to
each acquisition. Protect the private session store. Rollback: disable the
new option and use 0.23.0 with the previous caller-provided provisioning.
The existing Android source remains recoverable. No public release or live
source migration is established by these code changes.

See [source evidence and limits](docs/research/E15_MAP_PROVISIONING.md).

## 0.23.0 - 2026-09-25

### Mower work parameters

- `client.mowers.queryWorkParameters(id, signal?)` reads DP 155, the E15's
  work parameters, from the cloud record that discovery already requests,
  because the E15's local status replies do not carry it. The reading is
  `reported`, `missing` or `invalid`, with `source: 'cloud'` and the
  library's receipt time. The pure `decodeMowerWorkParameters(value)` decodes
  a base64 value with the numbering of the official app's product script:
  mow height, mow speed, edge distance, the direction configuration, mow
  spacing, blade speed and the current mow spacing. It is bounded and never
  throws.
- `session.setWorkParameter({ name, value, readBackMs? })` writes the mow
  speed (`low`, `medium`, `adaptive_high`) or the blade speed (`low`,
  `medium`, `high`) behind the existing `mowers.settings` opt-in. One cloud
  reading supplies the value before the write, one fresh status query decides
  the map-save refusal, and one control frame carries a partial DP 155
  message with only that field, the way the app writes one change. The
  read-back ends `reflected` only when a fresh report's DP 155 carries the
  written value, and returns every parameter of that report. A restore is a
  second deliberate call. The frozen `WRITABLE_WORK_PARAMETERS` export lists
  the written values.
- Edge distance, mow spacing, the direction, the mow height and the current
  mow spacing are read only. No permitted source gives the first two a bound,
  and a direction write replaces a nested configuration.
- The settings refusals apply. A failed, late or unusable cloud reading is
  `mower_setting_evidence_missing` and sends nothing. Refusals leave the
  session open.
- Sources: the app's product script on the owner's Mac for the numbering and
  the written values, and the second settings window of 2026-09-25, in which
  the owned E15 merged a partial DP 155 message written over the LAN outside
  the library. See [Mower work parameters](docs/MOWER_WORK_PARAMETERS.md) and
  the [settings window receipt](docs/research/E15_SETTINGS_WINDOW_2026-09-25.md).
- Upgrade: additive for callers. `MowerModule` gains `queryWorkParameters()`
  and `MowerLocalSession` gains `setWorkParameter()`, so a consumer that
  implements these interfaces itself, for example in a test double, adds them.
  The settings opt-in now also allows the two work parameter writes through
  the new call. Rollback: install 0.22.0 and drop the new calls.

Use the compiled versioned 0.23.0 tarball and its verified integrity from the
GitHub release. The change is verified in two ways:

- In software, by CI and synthetic tests of the decoder, the cloud reading, the
  one partial message per write, every refusal before a write and the
  read-back from fresh reports.
- On hardware, outside this code: the owned E15's cloud record carried DP 155
  with the same value as the cloud's data point request, and the E15 merged a
  partial DP 155 message written over the LAN and reported the complete
  message within about 0.2 seconds, both on 2026-09-25.

No work parameter has been written through the library on hardware. A
supervised window through the mower bridge, which pins this release, is the
next check in keesmod/eufy-robomow-ha#8. Retain the previous package and
lockfile for rollback.

## 0.22.0 - 2026-09-25

### DP 107 read as the mower's mission status

- The E15 registry gains a `mission_status` definition for DP 107
  `robot_status`. The official app's decoder reads DP 107 as the mower's
  mission status: field 1 is the mission, 2 the sub-mission, 3 the state, 4
  the power mode, 5 an error flag and 6 a saving-data flag.
- Every mowing mission now reports `mowing` while running and `paused` while
  paused. That covers the whole lawn, scheduled, zone, box and edge-trim tasks,
  mapping while mowing, temporary and remote-controlled mowing.
- The recharge mission reports `returning` while running.
- A message without mission, sub-mission, state or error flag reports
  `idle`. That includes the default payload, standby and hibernation (field 4
  = 2), and the saving-data flag after a map save.
- Before, only the whole-lawn and recharge payloads reported. A Box, zone or
  scheduled task and the idle message were `invalid`. The map save, the first
  frame of a start, a paused return, missions that do not mow and the error
  flag stay `invalid`. `idle` is not `docked`, because the same message
  follows the app's Stop on the lawn. See the
  [mission status receipt](docs/research/E15_MISSION_STATUS_SCHEMA_2026-09-25.md).
- Commands follow the same reading. A pause or resume of a Box task is now
  reflected by its `paused` or `mowing` report. A start sent while the app's
  mode is Box is reflected too. A stop still needs the exact map-saving
  payload, and command progress may now carry `idle`.
- `MowerTelemetryDefinition` gains a `mission_status` decode for status
  fields, with `mowing` and `returning` mission lists. The three existing
  `wire` definitions are unchanged, so `status.dp` lists `107` four times.
- Upgrade: additive. A consumer that treats `idle` as unknown keeps its
  earlier behaviour. Rollback: install 0.21.0.

Use the compiled versioned 0.22.0 tarball and its verified integrity from the
GitHub release. The change is verified in two ways:

- In software, by CI and synthetic tests of every mowing mission, the recharge
  mission, the idle message with each power mode and the withheld payloads,
  and by Box pause and resume reflection in the command session.
- On hardware, by every DP 107 value the owned E15 reported in the windows of
  2026-09-16 to 2026-09-25, recorded in the mission status receipt.

It changes the reading of DP 107 only, no device command, write, timeout or
transport, so no new physical test gates it. The field check is bridge mode on
the owned E15 once the mower bridge pins this release. Retain the previous
package and lockfile for rollback.

## 0.21.0 - 2026-09-25

### Live start stages

- `startLive(cameraId, { onProgress })` reports each stage of a start once,
  with the milliseconds since the call: `session_ready`, `start_issued`,
  `start_result` with the station's numeric `returnCode`, `no_data_end` and
  `metadata`. A start without media now says whether the station refused
  START, accepted it and sent nothing, or never answered. Before, the answer
  to START was dropped and a consumer saw only a start that did not resolve.
  Refs #187 and keesmod/ha-eufy-cam#94.
- The P2P session emits `livestream no data`, which the station forwards,
  when it ends a video stream that never started. It ended such a stream
  silently before. See [live start stages](docs/API.md#live-start-stages-0210).
- Start, stop, cancellation, timeouts and the concurrency limit are unchanged.
  The stages carry no identifiers and every value is bounded.
- Upgrade: additive. `LiveStartOptions` gains `onProgress`, and the types
  `LiveStartStage` and `LiveStartProgress` are exported. Rollback: install
  0.20.0 and drop `onProgress`.

Use the compiled versioned 0.21.0 tarball and its verified integrity from the
GitHub release. The change is software-verified: CI and synthetic tests of the
five start cases on an extra and the primary session, and of the P2P session's
new event. It observes the start only and changes no device command, timeout
or media path, so no new physical test gates it. The field check is the next
live start without media on keesmod/ha-eufy-cam#94 once the camera bridge pins
this release. Retain the previous package and lockfile for rollback.

## 0.20.0 - 2026-09-25

### Opt-in mower settings

- `session.querySettings()` and the pure `decodeMowerSettings(snapshot,
{ schema })` read seven E15 settings from one local status snapshot: mow
  height, volume, smart no-go zone suggestions, sparse lawn optimization,
  rain auto return, child lock and bird-view capture. Each is `reported`,
  `missing` or `invalid`, with its bound, step and unit for the value settings
  and `writable` from the library's table and the device's declaration.
- `session.setSetting({ name, value, readBackMs? })` writes one of four
  settings, `mowHeight` from 25 to 75 mm, `volume` from 0 to 100 %,
  `smartNoGoZones` and `sparseLawnOptimization`, behind a new explicit
  `mowers.settings` opt-in that is separate from `commands`. It follows the
  command lifecycle: one fresh status query, typed refusals before any write,
  one control frame, and a bounded read-back that ends `reflected` only when a
  fresh report carries the written value. The outcome returns the `previous`
  value. A restore is a second deliberate call. Nothing is retried, replayed,
  reconnected or restored by the library.
- Rain and child protection, DP 101 and DP 47, are read only in either
  direction, as the owner decided in keesmod/eufy-robomow-ha#8. The bird-view
  capture of the app's Real Lawn map is read only too. `setSetting()` refuses
  them with `mower_setting_read_only`.
- New refusals `mower_settings_disabled`, `mower_setting_invalid`,
  `mower_setting_read_only`, `mower_setting_undeclared`,
  `mower_setting_evidence_missing`, `mower_setting_map_saving` and
  `mower_setting_already_set`. New `client.mowers.settingsEnabled` and
  `session.settingsEnabled`.
- Sources: the device's own declaration, read in a read-only readout on the
  owned E15 on 2026-09-25, and the product script of the official app on the
  owner's Mac. See [Opt-in mower settings](docs/MOWER_SETTINGS.md) and the
  [settings schema receipt](docs/research/E15_SETTINGS_SCHEMA_2026-09-25.md).
- Upgrade: additive for callers. `MowerLocalSession` gains `settingsEnabled`,
  `querySettings()` and `setSetting()`, and `MowerModule` gains
  `settingsEnabled`, so a consumer that implements these interfaces itself,
  for example in a test double, adds them. Rollback: install 0.19.0 and drop
  the `settings` opt-in and the new calls.

Use the compiled versioned 0.20.0 tarball and its verified integrity from the
GitHub release. The change is software-verified: CI and synthetic tests against
the local peer, with the device's own declarations read in a read-only readout
on the owned E15 on 2026-09-25. No setting has been written on hardware yet.
The supervised change, read-back and restore of the mow height is pending in
keesmod/eufy-robomow-ha#8. Retain the previous package and lockfile for
rollback.

## 0.19.0 - 2026-09-24

### Command progress while the read-back runs

- `session.sendCommand()` accepts an optional `onProgress` callback. It
  receives the acknowledgement once and every fresh DP 107 report that decodes
  to a confirmed activity while the read-back still runs, as frozen copies.
  After a `stop` on the owned E15 that is `returning` within a second, where
  the outcome arrives only with the map-saving payload at the dock arrival
  about 30 seconds later. The mower bridge in keesmod/eufy-robomow-ha uses it
  to show the drive home, a finding of the control window of 2026-09-24 in
  keesmod/eufy-robomow-ha#8.
- The callback adds no evidence and no stage. Its errors are ignored and it
  cannot change, end, retry or replay a command. A non-function value is
  refused with `mower_command_invalid`. Without it nothing changes.
- Upgrade: additive, no identifier, session or outcome change. Rollback:
  install 0.18.1 and drop the callback.

Use the compiled versioned 0.19.0 tarball and its verified integrity from the
GitHub release. Only the command read-back gains the optional callback. The
change is software-verified: CI and synthetic command tests with the report
order recorded on 2026-09-20. No new hardware test was needed because the
callback only forwards reports the confirmed definitions already decode. Retain
the previous package and lockfile for rollback.

## 0.18.1 - 2026-09-23

### Video Doorbell C30 reported with device type 96

- Discovery admits a C30 that Eufy reports as model `T8224` with device type
  `96`, as in the report on
  [ha-eufy-cam#40](https://github.com/keesmod/ha-eufy-cam/issues/40). It gets
  the same battery doorbell adapter, HomeBase 3 topology and snapshot, live and
  recording policy as `T8224` with type `95`. Earlier versions rejected it as
  `unsupported_device`. Only this exact pair is added. Every other model keeps
  its single type, and `T8224` with any other type stays unsupported.
- The pair is a reported inventory value, not independently reproduced, and no
  hardware was tested. Details are in
  [Battery doorbell evidence](docs/BATTERY_DOORBELLS.md#reported-c30-type-96-0181).
- Upgrade: no API, identifier or session change. Rollback: install 0.18.0,
  which rejects the pair again. References #183.

Use the compiled versioned 0.18.1 tarball and its verified integrity from the
GitHub release. Only discovery and media admission of the exact `T8224` type
`96` pair change. Protocol, commands, media code, camera identifiers and
persisted sessions are unchanged. The change is software-verified only: CI and
synthetic adapter, media, lifecycle, capability and discovery tests. The
reported C30 has not been tested on hardware. Retain the previous package and
lockfile for rollback. The camera bridge pins this release separately in
keesmod/ha-eufy-cam. References #183.

## 0.18.0 - 2026-09-23

### Typed E15 map geometry decoding

- Add `decodeMowerMapSnapshot`, `decodeMowerMapFile`, `decodeMowerPathFile` and
  `decodeMowerPoseFile` with the `MowerMap`, `MowerPath`, `MowerMapPose` and
  related types. They decode the three files that `PortableMapAcquisition`
  retains into read-only geometry: map identity, grid and bounds, station
  pose, region boundaries with sub-regions, obstacles, virtual and physical
  forbidden zones, virtual walls, cross-boundary tunnels, pass-through and
  required zones, trap and maintenance markers, the mowing history path with
  point kinds and end pose, and the six-byte pose record of
  `navPath.bin.stream`. The numbering comes from the original parser and is
  validated against the retained captures, recorded with its provenance in
  [Decoded mower map geometry](docs/MAP_GEOMETRY.md).
- Every file decodes independently and never throws. Malformed input reports
  the structural reason, byte offset and message path per file, unknown
  enumeration values keep their code, undecoded field numbers are listed,
  degenerate polygons, lines and ellipses are flagged and never repaired, and
  grid issues are reported. Integers stay integers because no source states
  the unit, and the pose values are display only. No mowing zone is invented,
  nothing is editable and E18 is not covered.
- Upgrade: additive API on the same `PortableMapAcquisition` contract, no
  change to acquisition, commands, telemetry, camera identifiers or persisted
  sessions. Rollback: install the previous package. References #51, next step
  #178.

### Accumulated cleaning-path history

- Add `MowerPathAccumulator` with the `MowerPathHistory`, `MowerPathSegment`,
  `MowerMapGeneration`, `MowerPathMergeInput`, `MowerPathMergeResult`,
  `MowerPathStartReason`, `MowerPathRejection` and
  `MowerPathAccumulatorOptions` types. `merge` takes the decoded geometry of
  each acquisition snapshot in receipt order and keeps one ordered history per
  map identity and generation: successive `history` paths of one map extend
  it by the points they add, every segment records the acquisition revision
  and `receivedAt` it came from, the end pose and the path kind follow the
  latest history or complete path, and every point keeps its kind and code.
  A changed map id, path id or map generation (grid, origin or save time) and
  a history that diverges from the confirmed points start a new history and
  return the previous one instead of mixing. A `realtime` path only extends
  the history provisionally and never replaces its points, kind or end pose,
  the empty realtime placeholder that opens each demand changes nothing, and
  malformed, duplicate, out-of-order and oversized inputs are rejected with a
  reason while the existing history stays untouched. Histories are frozen
  plain data and the merge invents no point, order or timing.
- Upgrade: additive API on the same `PortableMapAcquisition` contract and the
  #51 decoder, no change to acquisition, commands, telemetry, camera
  identifiers or persisted sessions. Rollback: install the previous package.
  Software evidence only, the merge rules and their confirmation levels are in
  [Decoded mower map geometry](docs/MAP_GEOMETRY.md). References #178.

### Hardware evidence for stop and return, documentation only

- The owner-operated window of 2026-09-20 recorded in the
  [stop and return receipt](docs/research/E15_STOP_RETURN_WINDOW_2026-09-20.md)
  confirms the 0.17.0 `stop` class on the owned E15 with firmware 6.9.28:
  DP 1 `switch_go` false was echoed 0.6 seconds after the write, the device
  reported `returning` 0.3 seconds after it and drove to the dock by itself,
  and the map-saving payload reported in `payload` arrived at dock arrival 30
  seconds after the write. A plain DP 1 false therefore ends the task and
  returns the mower, it does not leave it stopped on the lawn with or without
  its progress. `return` over DP 3 `switch_charge` sent from the stopped task
  that the app's Stop with Clear Progress had reached ended `timed_out`
  without a report or a physical effect, as it had from `paused`. The
  library has no DP 3 return route on this firmware, `stop` is the library
  route that brings the mower home, and the app's Charge over the raw control
  points remains the only way back from a task stopped on the lawn. Model
  matrix, [Opt-in mower commands](docs/MOWER_COMMANDS.md) and the API notes
  carry the evidence. No code, type or package change. References #173.

Use the compiled versioned 0.18.0 tarball and its verified integrity from the
GitHub release. Without the map API nothing changed. A consumer of
`PortableMapAcquisition` gains the read-only decoding of #51 and the history
accumulator of #178 as additive functions and types on the same snapshot
contract, and the stop and return evidence of #173 is documentation only. Both
map changes are software-verified only: CI, synthetic fixtures and the retained
captures of 2026-09-10 decoded and replayed locally without wire-type
conflicts. A fresh acquisition decoded end to end on the owned E15, the
coordinate and heading units, the meaning of `navPath.bin.stream` and the
merged history against the app's displayed path remain open hardware
obligations, so the pose values stay display only. Commands, telemetry, the
camera modules and persisted sessions are unchanged. Retain the previous
package and lockfile for rollback. The mower bridge pins this release
separately in keesmod/eufy-robomow-ha. References #51, #178 and #173.

## 0.17.0 - 2026-09-19

### Opt-in stop and the return precondition

- Add the opt-in command class `stop`. `session.sendCommand({ kind: 'stop' })`
  writes DP 1 `switch_go` false, the value the protocol owner assigns to
  stopping the job and the value reported after every app Stop on the owned
  E15. Its acknowledgement is DP 104 `stop_control` or the echo of the written
  point, and its reflection is the map-saving DP 107 payload, fields 2 = 5 and
  3 = 1 as the only records, reported in the new outcome field `payload`
  instead of `activity`. The same opt-in, exclusive ownership, typed refusals,
  bounded read-back and absence of retry, replay and reconnect apply.
- `return` is refused before any write with the new `mower_command_task_active`
  while DP 1 is not `false` on the fresh query, and with the existing
  `mower_command_map_saving` unless DP 118 reads exactly 100. The official app
  offers Charge only after Stop and the map save, and a return sent from
  `paused` was ignored on firmware 6.9.28, so the library now sends `return`
  only from the stopped task. The library cannot tell docked from stopped on
  the lawn, so a return sent while docked is not refused.
- Additive types: `MowerCommandKind` gains `stop` and `MowerCommandOutcome`
  gains the optional `payload`. Synthetic tests cover the stop lifecycle, stop
  without its reflection, the DP 107 shapes that never reflect it, the new
  refusal and stop followed by return on one session. The contract and the
  sources are in [Opt-in mower commands](docs/MOWER_COMMANDS.md).
- Hardware evidence: none yet for `stop` and for `return` from the stopped
  task. Both are software only until the owner-operated window of #173, which
  also records whether a plain DP 1 false keeps or clears the mowing progress.
  `start`, `pause` and `resume` keep their confirmed evidence from 0.16.0.
  References #173.

Use the compiled versioned 0.17.0 tarball and its verified integrity from the
GitHub release. Without `mowers.commands` nothing changed. A consumer that
opts in gains `stop` and must expect `mower_command_task_active` from a
`return` sent while the task is active, where 0.16.0 wrote DP 3 and timed out.
Until the window of #173 reports otherwise, `stop` and `return` from the
stopped task are unconfirmed on hardware and `return` still has no confirmed
route on firmware 6.9.28. Public types are additive, the telemetry definitions
and the camera modules are unchanged. Retain the previous package and lockfile
for rollback. The mower bridge pins this release separately in
keesmod/eufy-robomow-ha. References #173.

## 0.16.0 - 2026-09-19

### Opt-in E15 commands

- Add `mowers.commands: { enabled: true, stopRoute, readBackMs? }` as the only
  way to enable physical control, and `session.sendCommand({ kind })` for
  `start`, `pause`, `resume` and `return`. Each call runs one fresh status
  query, writes one declared boolean point, DP 1 `switch_go`, DP 2 `pause` or
  DP 3 `switch_charge`, and reads the lifecycle back from fresh reports within
  a bound: `stage` is `sent`, `acknowledged` or `reflected` and `end` is
  `reflected`, `rejected`, `timed_out` or `report_limit`. A sent command is
  never reported as completed and dock arrival is never inferred.
- Typed refusals before any write: `mower_commands_disabled`,
  `mower_command_invalid`, `mower_command_undeclared`,
  `mower_command_evidence_missing`, `mower_command_map_saving` and
  `mower_command_already_set`. One command owns the session at a time. There
  is no retry, replay or reconnect. Rain and child protection are never
  touched. Without the opt-in nothing changed.
- The control frame, its sources and the reasons for not writing the raw
  control points are in [Opt-in mower commands](docs/MOWER_COMMANDS.md) and
  the [control-point receipt](docs/research/E15_CONTROL_POINTS_2026-09-19.md).
- Hardware evidence: one owner-operated window on firmware 6.9.28 with app
  6.1.00, see
  [the command window receipt](docs/research/E15_COMMAND_WINDOW_2026-09-19.md).
  `start`, `pause`, `resume` and a second `pause` ended `reflected` within 1.2
  seconds of the write. `return` over DP 3 `switch_charge` ended `timed_out`
  without any report or effect, so firmware 6.9.28 does not honour it and a
  consumer must treat a `timed_out` return as no effect. The app's Stop, Clear
  Progress and Charge returned the mower while the library listened. The model
  matrix records start, pause and resume as confirmed and return as not
  honoured. References #169.

Use the compiled versioned 0.16.0 tarball and its verified integrity from the
GitHub release. Without `mowers.commands` nothing changed: the local session
still never writes and `sendCommand()` is refused with
`mower_commands_disabled` before any frame. A consumer that opts in must name
its stop route, send one command at a time and treat `timed_out` as an unknown
device state that is never retried. On the owned E15 with firmware 6.9.28
`start`, `pause` and `resume` are confirmed and `return` over DP 3 has no
effect, so a consumer must not offer return as a working control on this
firmware. Public types are additive, the telemetry definitions and the camera
modules are unchanged. Retain the previous package and lockfile for rollback.
The mower bridge pins this release separately in keesmod/eufy-robomow-ha.
References #169, #171 and #172.

## 0.15.0 - 2026-09-19

### Confirmed E15 activity

- `E15_TELEMETRY_DEFINITIONS` ships the three DP 107 `robot_status` payloads
  at `confirmed`: fields 1 = 2 and 3 = 1 `mowing`, 1 = 2 and 3 = 2 `paused`,
  1 = 1 and 3 = 1 `returning`. `queryTelemetry()` and `decodeMowerTelemetry`
  now report `status` for these payloads on the owned E15 instead of
  `{ state: 'unconfirmed', level: 'observed' }`. An absent DP 107 reports
  `missing`, and a transitional, map-saving, field 6 or default payload
  reports `invalid` for that report. The `mowing` payload also covers the
  app's Defogging phase. Types and other definitions are unchanged.
- Evidence: three further owner-operated start, pause and return cycles on
  firmware 6.9.28 with app 6.1.00, see
  [the reproduction receipt](docs/research/E15_ROBOT_STATUS_REPRODUCTION_2026-09-19.md).
  References #156.

Use the compiled versioned 0.15.0 tarball and its verified integrity from the
GitHub release. The only runtime change is the E15 registry: `status` now
reports `mowing`, `paused` or `returning` from DP 107 instead of
`{ state: 'unconfirmed', level: 'observed' }`, reports `missing` without DP
107 and `invalid` for the transitional, map-saving, field 6 and default
payloads. A consumer that branched on the unconfirmed state should handle the
reported, missing and invalid states. Public types, the other definitions and
the camera modules are unchanged. Retain the previous package and lockfile for
rollback. The mower bridge pins this release separately in
keesmod/eufy-robomow-ha. References #156 and #168.

## 0.14.0 - 2026-09-19

### Per-start live bound and a free primary session

- Add `liveUpperBoundMs` (120000 to 3600000, default 120000) and
  `startLive(cameraId, { signal?, maxDurationMs? })`. A stream may ask for a
  bound between one second and the ceiling, otherwise `invalid_live_bound`.
  Without a per-start value the bound stays 120 seconds whatever the ceiling.
  `startLive(cameraId, signal?)` keeps working.
- With `maxLiveStreamsPerStation` above 1, every live stream now uses its own
  P2P session, including the first one, so the primary session stays free.
  Mode commands, state refreshes and snapshots work while cameras stream.
  Recording transfers, reloads and recovery of a camera without a stream still
  fail with `station_busy` or `devices_busy` while any stream runs. With the
  default of 1 nothing changed.
- Bench evidence on one T8030 with one T8160, see
  [the research note](docs/research/LIVE_BOUND_2026-09-19.md).

Use the compiled versioned 0.14.0 tarball and its verified integrity from the
GitHub release. Both options keep their defaults, so consumers keep one live
stream per station on the primary session with a 120-second bound until they
opt in. A longer stream needs a raised `liveUpperBoundMs` and an explicit
`maxDurationMs` per start. Retain the previous package and lockfile for
rollback. The camera bridge pins this release separately in keesmod/ha-eufy-cam.
References #163, #165 and #166.

## 0.13.0 - 2026-09-18

### Concurrent live streams per station

- Add `maxLiveStreamsPerStation` (1 to 4, default 1). Above 1, every further
  concurrent live camera on a station opens its own P2P session, keyed by
  station and channel, with its own STOP confirmation, 120-second cap, abort
  cleanup and disposal. The primary session keeps control, snapshots,
  recordings and the first stream. The same camera twice, a start beyond the
  limit, and recording transfers or mode commands during live still fail with
  `station_busy`. Default behaviour is unchanged.
- Verified with two concurrent T8160 streams on one T8030, see
  [the research note](docs/research/CONCURRENT_LIVE_2026-09-18.md). Three or
  four streams are unverified on hardware.

### Read-only local mower session

- Add `EufyClient.mowers.openLocalSession(id, { host })` for one authenticated Tuya
  LAN protocol 3.5 session to one discovered E15. `queryStatus()` returns a copied
  snapshot with `source`, local `observedAt` and raw `dps`. No data point is
  interpreted or written. There is no command, setting, retry, reconnect or
  automatic polling.
- Borrow the private local key from the verified cloud binding only during key
  negotiation and erase it afterwards. Public results never contain the key,
  device ID or host. Every failure is a stable `EufyError` code without upstream
  detail, and failed or closed sessions release their socket and timers.
- Record every protocol fact with its permitted public source, pinned revisions
  and file digests in [Mower transport provenance](docs/MOWER_TRANSPORT_PROVENANCE.md).
  The frame codec and session-key derivation are reproduced byte for byte with
  tinytuya 1.20.0 and covered by synthetic peer tests. The subsequent
  [E15 6.9.28 observations](docs/research/E15_TELEMETRY_OBSERVATION_2026-09-16.md)
  confirm bounded local queries, schema retrieval and session cleanup.

### Typed mower telemetry

- Add `session.queryTelemetry()` and the pure `decodeMowerTelemetry()` that turn
  one snapshot into `status`, `battery`, `progress` and `network` fields with
  `source` and `observedAt`, plus every reported data point typed by the device's
  own declared schema and the raw `dps` copy. Nothing is inferred from age or
  absence.
- Retain the device's data-point schema from discovery and expose a copy as
  `session.schema`. Typed values come only from `confirmed` definitions that also
  conform to the declaration. The shipped E15 registry now includes independently
  observed battery percentage, Wifi and signal percentage. `signalPercent` is
  additive and keeps DP 109's declared `%` unit separate from `signalDbm`.
  Activity, mowing progress and unobserved network modes remain unconfirmed.
  Consumers may pass their own confirmed definitions. See
  [typed mower telemetry](docs/MOWER_TELEMETRY.md).

### Spontaneous mower reports

- Add `session.receiveReport()` for bounded, authenticated command-8 reports.
  It preserves full-frame arrival time, distinguishes reports from query replies,
  and returns each report's own data points without merging older values.
- Keep a pending report read alive with transport-only heartbeats. Preserve one
  operation per session, bounded buffering, cancellation, timeout and shutdown.
  No DP refresh, command write, retry or reconnect is added. See the
  [report API](docs/API.md#spontaneous-mower-reports-0130).

### E15 activity report contract

- Establish the DP 107 `robot_status` envelope from the protocol owner's base64
  raw report path and the public Protocol Buffers encoding rules, verified
  against every retained raw value of the owner-operated windows. Add the pure
  bounded `parseMowerWirePayload()` and expose its structural result as
  `fields[dp].wire` for data points named by a `wire` definition.
- Add the `wire` decode kind for evidence-gated candidate readings of a raw
  payload. Ship the mowing, paused and returning candidates for DP 107 at
  `observed`, so `status` now reports `unconfirmed` with that level and no
  activity value until three app-correlated reproductions exist. Battery,
  network and the report freshness rules are unchanged. See the
  [contract receipt](docs/research/E15_ROBOT_STATUS_CONTRACT_2026-09-16.md).

### Cloud identity renewal

- Discard the cached key-exchange identity and persist the cleared session when
  the Mega cloud answers with result code 4404 or 4416, also when that body
  arrives with a non-2xx status such as HTTP 463. That reset was unreachable
  before because every non-2xx response failed as `http_error` first, so a
  stored session whose identity had been invalidated elsewhere, for example by
  a key exchange on the same token from another host, failed every restore
  attempt. Observed with camera bridge client 0.12.3 on 2026-09-18 in #157.
- The rejected call now fails with `request_rejected`, `key_exchange_failed` or
  `authentication_rejected` carrying the remote code instead of `http_error`.
  Every other non-2xx response keeps `http_error`. No automatic retry is added.
  The next explicit call performs a fresh key exchange.

### Upgrade and compatibility

Existing camera and mower APIs, identifiers, persisted sessions and the map
acquisition adapter are unchanged. Consumers that matched `http_error` for a
rejected cloud identity now receive the remote result code instead. The
`MowerAdapter` contract is unchanged, so custom adapters keep working and report
`mower_protocol_unavailable` for local sessions. The local session interface gains `schema`, `queryTelemetry()` and `receiveReport()`.
`MowerTelemetryValue` gains the optional `wire` property and status definitions gain
the `wire` decode kind. Consumers that matched `status` against `{ state: 'unconfirmed' }`
exactly now also see `level: 'observed'`.
Use the compiled versioned 0.13.0 tarball and its verified integrity from the
GitHub release. `maxLiveStreamsPerStation` defaults to 1, so consumers keep one
live stream per station until they opt in. Retain the previous package and
lockfile for rollback. The camera bridge pins this release separately in
keesmod/ha-eufy-cam. References #145, #147, #149, #150, #153, #157, #159, #160
and #161.

## 0.12.3 - 2026-09-15

### Easier device maintenance

- Consolidate all 51 existing device profiles and per-feature media rules in
  one typed registry. Preserve exact model/type, owner and firmware admission,
  including the four established routes. Snapshot, live and recording
  capabilities retain their independent failures and current public shape.
- Generate and check the software-policy table from the same registry. Existing
  model/topology behavior is characterized before and after the refactor.
  This change adds no model, transport or hardware support claim.
- Give maintainers one place to review a known-family device addition and its
  snapshot, live and recording rules. Characterization tests detect changes to
  existing profiles. New protocols still require implementation and hardware
  validation before support can be claimed.

### Late audio discovery

- Keep audio codec discovery open after bounded video-only startup. The first
  late AAC packet is classified and normalized without a second stream-start
  event or camera command. Live handle metadata reflects the observed codec.
- Preserve the three-second startup limit for cameras that send no audio.
  Consumers must explicitly support adding a late audio track. This library
  correction alone does not add audio to an existing browser connection or
  establish T8134 acceptance for camera issue #10.

### Upgrade and compatibility

Use the compiled versioned 0.12.3 tarball and its verified integrity. The combined
[camera 0.8.19 release](https://github.com/keesmod/ha-eufy-cam/pull/81) consumes
this version. Other consumers must validate their own late-audio handling and
bridge behavior. Public API shapes, identities and admission boundaries remain
compatible. Retain the previous package and lockfile for rollback and preserve
the private credential/session store. No data migration is required.

References #139 and [camera #78](https://github.com/keesmod/ha-eufy-cam/issues/78).

## 0.12.2 - 2026-09-11

### Logging improvements for diagnostics

- Add bounded firmware, hardware and received parent context to rejected security
  inventory rows. Distinguish absent, self, missing, ambiguous and invalid parents.
  Private parent identifiers are only for consumer-side anonymous correlation.
- Preserve model admission, topology guards and mixed inventories. This supplies
  support evidence for camera issue #40 without claiming its cause or a C30 fix.

## 0.12.1 - 2026-09-11

- Add optional bounded `deviceModel` and `deviceType` diagnostics to
  `unsupported_device` discovery issues. Omit invalid values without coercion
  or truncation. Keep existing error codes, identities and model admission.
- Allow consumers to diagnose unknown model/type pairs without logging raw
  inventory. Consumers must still exclude the existing private `deviceId` field.
- This diagnostic patch follows [camera issue #40](https://github.com/keesmod/ha-eufy-cam/issues/40).
  It does not establish why the reported C30 is missing or add hardware support.

## 0.12.0 - 2026-09-11

- Combine the unpublished SoloCam discovery/media work with exact H3 profiles
  for Indoor, Floodlight, Wall-light, eufyCam C35, T86P2 in Wi-Fi mode and camera
  functions in three integrated products. Reuse existing attributed protocol
  classes and command paths. Preserve T8134 admission and existing identities.
- Add stored snapshots, live video/audio and recording software coverage only
  behind the actual admitted owner and existing firmware guards. Preserve
  acknowledged stop/cancel, bounded cleanup and independent owners. Missing
  battery or availability observations remain unknown.
- Recognize four wired doorbell and two garage camera model/type pairs with
  explicit standalone/owner blockers. Recognition does not activate their
  missing authentication, events or media. No lock, lid, garage-door, light or
  PTZ controls are added.
- Record reproducible standalone, older-owner, LTE and PoE/NVR protocol limits,
  including a bounded offline descriptor inspector that omits private values.
  Unimplemented connections and unresolved model variants remain open.
- Allow one explicitly tracked unpublished candidate version across related
  runtime PRs. Updated release notes are required. Existing tags, releases or
  drafts and failed remote checks reject that exception. All CI and immutable
  publication checks remain required.
- See the [0.12.0 candidate notes](docs/RELEASE_0_12_0.md) for exact models,
  source evidence, consumer limits and remaining obligations. Software tests
  do not add hardware support or resolve the T8134 audio report. No session
  migration is needed. Retain the previous package, lockfile and private store
  for rollback. This candidate has not been published or deployed.

## 0.11.0 - Unreleased

- Add exact SoloCam discovery, observed state and motion/person event routing for
  ten model/type pairs behind the existing T8030 HomeBase 3 owner. Select the
  private SoloCamera adapter while preserving eufyCam and doorbell adapters.
- Preserve T8134 identities and existing media admission. Additional SoloCam media
  stays explicitly unverified. Standalone descriptors identify their own owner
  without enabling an unverified connection or creating a HomeBase entity.
- See [SoloCam software evidence](docs/SOLOCAM.md). No new hardware support,
  session migration or physical control is claimed. Retain the preceding package
  and private store for rollback. This version is not published.

## 0.10.0 - 2026-09-11

- Add `getCameraCapabilities()` for snapshot, live and recording software admission.
  Results use the existing media and owner guards without connecting to devices.
  Available operations remain experimental. Hardware acceptance is unchanged.
- Preserve existing methods and private session stores. No migration is needed.
  Retain the preceding package and store for rollback.

## 0.9.0 - Unreleased

- Enable stored snapshots, live video/audio and recordings for exact T8214/94,
  T8224/95 and T8223/96 behind the existing T8030 H3 local LAN-derived profile.
  Require the documented numeric owner firmware branch. Preserve T8213 media.
- Validate separate E340 and C30/C31 live commands, acknowledged stop/cancel,
  bounded cleanup and failure isolation with synthetic family fixtures.
- See [battery doorbell media evidence](docs/BATTERY_DOORBELLS.md#h3-core-media-090).
  Hardware acceptance remains open. No session migration is required. Retain
  the preceding package and private store for rollback. No release is published.

## 0.8.0 - Unreleased

- Admit exact T8214/94, T8224/95 and T8223/96 battery doorbells behind the existing
  T8030 owner and select the private BatteryDoorbellCamera adapter.
- Preserve observed state, battery, firmware, owner/property-filtered detections,
  distinct ring events and replay suppression. Preserve existing camera identities.
- Keep new doorbell media explicitly unverified and retain the T8213 media route.
  Candidate type 7/16 variants and unsupported owners remain explicit.
- See [battery doorbell software evidence](docs/BATTERY_DOORBELLS.md). No hardware
  claim or session migration is added. Retain the preceding package and private
  session store for rollback. This version is unreleased.

## 0.7.0 - Unreleased

- Enable exact eufyCam model/type media profiles behind T8030 using existing
  H3 local LAN-derived command paths. Require the documented owner firmware
  branch for newly admitted models. Keep unknown profiles explicitly unsupported.
- Preserve stored snapshots, live video/audio, recording history and downloads,
  with per-model command and lifecycle fixtures. No new hardware support is claimed.
- Require the matching camera channel for local live-stop confirmation. Remove
  pending recording EOF listeners after cancellation and suppress duplicate listeners.
- Check unsupported camera-bound recording access before opening its connection.
- See [eufyCam media evidence](docs/EUFYCAM.md). Version 0.7.0 is unreleased.
  No session migration is required. Retain the preceding package and private
  session store for rollback.

## 0.6.0 - Unreleased

- Admit twelve exact eufyCam model/type pairs behind the existing HomeBase 3 owner.
  Keep unsupported owners and unresolved model variants explicit and isolated.
- Add optional `Device.availability` and `getDeviceState()`. Report observed battery
  and status values without SDK numeric coercion. Preserve existing identifiers.
- Filter detections by camera properties and actual owner, retaining event identity,
  duplicate suppression and existing doorbell ring semantics.
- Newly admitted models reject media with `camera_media_unverified` pending #20.
  Existing media routes remain unchanged. No new hardware support is claimed.
- See [eufyCam software evidence](docs/EUFYCAM.md). No session migration is needed.
  Retain the previous package and private store for rollback. This version is unreleased.

## 0.5.0 - Unreleased

- Add typed discovery relationships and per-device reasons through `discoverDevices()`.
  Keep existing `listDevices()` results and camera/HA identifier fields compatible.
- Isolate unknown models, unsupported owners and device initialization failures.
  Preserve duplicate identity, malformed relationship and inventory-cap errors.
- Represent standalone T8134 ownership without a false HomeBase or unverified
  transport. Wire/auth research remains in #36. No hardware support is added.
- See [discovery evidence and migration notes](docs/DISCOVERY.md). No session-store
  migration is required. Retain the previous package and private store for rollback.
  This version is unreleased.

## 0.4.0 - Unreleased

- Add the bounded read-only `PortableMapAcquisition` library adapter for the three
  independently evidenced E15 streams, using Node built-ins and explicit private
  RTC provisioning. No Android or remote helper runs in the acquisition path.
- Preserve complete transport files across partial, oversized, unordered or
  contradictory replacements. Demand expiry, abort, disconnect and shutdown
  close owned resources and report peer cancellation separately.
- Keep camera and mower credentials separate and preserve existing public APIs.
  Synthetic lifecycle coverage does not establish new hardware support.
- See [acquisition contract and evidence](docs/MAP_ACQUISITION.md). This version
  is unreleased. No persisted-session migration is required. Retain the previous
  package and original map source for rollback.

## 0.3.1 - Unreleased

- Accept the independently observed EU appliances Home endpoint without widening
  the host allowlist to arbitrary subdomains.
- Keep the Home login name and native Tuya account UID separate. Internal private
  connections now use the UID returned by the authenticated Tuya session.
- Verify E15 discovery, local-key equality and SID reuse with the compiled library
  on the account owner host. Public results remain free of connection secrets.
- Existing 0.3.0 prototype stores without the native UID fail closed. Reconnect
  with a fresh private mower store after retaining its backup. No production
  store migration, release publication or deployment is included.

## 0.3.0 - Unreleased

- Add an independent Home/Tuya mower authentication adapter and E15 discovery
  profile to the modular API. Public device results exclude connection secrets.
- Bound requests and session reuse, validate regional hosts and revoke private
  connection access on cancellation, shutdown and renewed discovery.
- Preserve EufyMegaClient compatibility and separate camera/mower stores.
  Default mower authentication now uses Home/Tuya when no custom adapter is set.
- Include Apache-2.0 protocol attribution and the inherited MIT app-profile notice.
- Live E15 account binding remains pending explicit approval of the prepared
  experiment. This version is unreleased and adds no hardware support claim.
- Keep each mower store private. A custom adapter retains its own session format.
  To roll back, retain the previous package and its private store backup.

## 0.2.1 - Unreleased

- Preserve duplicate-event suppression when a saved event cache is restored in
  the same millisecond it was exported. Keep the five-minute expiry bound.
- Add synthetic family, topology, command and media lifecycle regression fixtures.
  These establish software behavior only. They do not add model support.
- Consumers can update to this library version when it is published. No session
  migration is required. Retain the previous package for rollback.

## 0.2.0 - 2026-09-10

- Add `EufyClient` with optional, independent security and mower modules. Keep
  `EufyMegaClient` and all existing exports compatible.
- Give each module its own authentication state, cancellation and shutdown.
  Separate bridge consumers use separate instances and private session stores.
- Define the mower adapter and opaque session contracts. No mower protocol ships
  in this version. Without an adapter, login reports `mower_protocol_unavailable`.
- Validate module isolation and public TypeScript consumers with synthetic
  fixtures. This adds no hardware support claims or bridge deployment.

## 0.1.1 - 2026-09-10

- Include eufyCam S220 / 2C Pro T8142 and SoloCam S220 T8134 in Mega
  discovery when paired with T8030 HomeBase 3. Fixes the model exclusion
  described in ha-eufy-cam issue #10 when using the Mega backend.
- Retain the HomeBase 3 parent requirement and existing device-specific protocol
  commands. Standalone SoloCam operation is outside this change.
- Upgrade the consuming bridge to a release that pins library 0.1.1. Keep the
  previous bridge version and private session backup for rollback.
- S220 hardware validation is pending; automated tests do not establish live
  video, audio, recording or event compatibility.

## 0.1.0 — 2026-09-10

- Independent Mega authentication, session persistence and discovery for the
  initial T8030/T8160/T8213 installation.
- Explicit LAN connection credentials, with no legacy cloud API fallback.
- Library-owned typed device, event, snapshot, live, recording and Guard Mode APIs.
- Device acknowledgement and telemetry checks for stop, transfer completion and
  Guard Mode. Cancellation and shutdown retain cleanup ownership.
- FCM reconnection and persisted duplicate suppression.
- Allow delayed first AAC packets within a bounded three-second audio discovery
  window; start immediately once both media types are identified.
- MIT attribution, protocol tests and compiled GitHub package distribution.

Hardware and HA acceptance passed on the target installation, including the
agreed 11-hour-26-minute overnight observation. This does not establish full
24-hour reliability or improved battery life. See the compatibility results.
